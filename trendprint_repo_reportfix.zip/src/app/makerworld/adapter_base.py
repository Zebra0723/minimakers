from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.schemas import MakerWorldModel, ModelStats


@dataclass(frozen=True)
class MakerWorldSearchResult:
    model_id: str
    title: str
    makerworld_url: str
    creator: str = ""
    tags: list[str] | None = None
    license: str | None = None
    stats: ModelStats | None = None
    published_at: datetime | None = None
    raw: dict[str, Any] | None = None


class MakerWorldSearchAdapter(ABC):
    @abstractmethod
    def search(self, keyword: str, limit: int = 20) -> list[MakerWorldSearchResult]:
        ...

    @abstractmethod
    def fetch_details(self, result: MakerWorldSearchResult) -> MakerWorldModel:
        ...
