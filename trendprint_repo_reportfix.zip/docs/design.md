# TrendPrint — Technical design

## Goal

Continuously discover **emerging UK topics** (Google Trends) and map them to **blind-box-friendly 3D prints** (MakerWorld), producing an explainable shortlist of models that are:

- **Small** (≤ 80mm longest dimension, or safely scalable down)
- **Fast** (≤ 90 minutes)
- **Low material** (≤ 30g)
- **Mainstream & kid-friendly** (target audience: 10–11)
- **Print-friendly** (minimal supports; durable geometry)
- **Commercially sellable** (**hard gate**: license must clearly permit commercial physical prints)

The pipeline runs every **2–6 hours** and writes:
- `reports/recommendations_YYYYMMDD_HHMM.json`
- `reports/recommendations_YYYYMMDD_HHMM.md`

---

## High-level architecture

### Pipeline steps

1. **trends_ingestor**
   - Fetch top trending searches for UK.
   - For each trend keyword: pull related queries + recent interest history.
   - Compute a `momentum_score` (0–100).

2. **keyword_normalizer**
   - Normalize text (case, whitespace, punctuation).
   - Deduplicate.
   - Expand into search variations (singular/plural, simple synonyms).
   - Filter out disallowed/unsafe terms early.

3. **makerworld_search_adapter** (swappable)
   - `dataset` adapter (default): searches a local JSONL dataset.
   - `web` adapter (optional): polite cached HTTP fetcher (best-effort robots check).
   - Returns model candidates with title/creator/tags/stats/license where possible.

4. **model_classifier**
   - Lightweight rule-based classifier:
     - `fidget`, `figurine`, `mini-toy`, `utility`, `other`
   - Confidence derived from keyword hits.

5. **printability_estimator**
   - Prefer MakerWorld print profile estimates when present.
   - Else: infer:
     - `max_dimension_mm` (from metadata or description patterns)
     - `grams_est` and `time_minutes_est` via bounding-box heuristics and settings assumptions
   - Adds `supports_likely` and durability penalties.

6. **license_filter** (**hard gate**)
   - Reject if license is missing/unknown/ambiguous.
   - Reject if license is non-commercial or personal-use only.
   - Optionally allow “commercial membership” items only when explicitly configured.

7. **scoring_ranker** (0–100, explainable)
   - Computes factor scores:
     - trend strength
     - relevance
     - popularity
     - freshness
     - printability
     - blind-box fit
   - Weighted sum → `total`.
   - Converts to `DO / MAYBE / SKIP`.

8. **notifier**
   - Write JSON + Markdown reports.
   - Optional: send to Slack/Discord webhook.

---

## Data model (Postgres via SQLAlchemy)

### `runs`
Tracks one pipeline execution.

- `id` UUID PK
- `region` (e.g., `UK`)
- `started_at`, `finished_at`
- `status` (`running|success|error`)
- `error_message` (nullable)

### `trend_snapshots`
- `id` UUID PK
- `run_id` FK → `runs.id`
- `region`
- `keyword` (raw trend)
- `momentum_score` float
- `evidence_json` (related queries)
- `raw_json` (optional debug)
- Unique: `(run_id, keyword)`

### `keywords`
- `id` UUID PK
- `run_id` FK
- `source_keyword` (trend keyword)
- `normalized_keyword`
- `expansions_json`
- Unique: `(run_id, normalized_keyword)`

### `makerworld_results`
Results from searching MakerWorld per keyword.

- `id` UUID PK
- `run_id` FK
- `keyword` (normalized keyword used for search)
- `model_id` (string)
- `makerworld_url`
- `title`, `description`, `creator`
- `license`
- `tags_json`
- `stats_json` (likes/downloads/makes)
- `published_at`
- `raw_json` (optional)
- Unique: `(run_id, keyword, model_id)`

### `model_scores`
- `id` UUID PK
- `run_id` FK
- `keyword`, `model_id`
- `total_score` float
- `verdict` (`DO|MAYBE|SKIP`)
- `scores_json` (breakdown)
- `notes_json`
- Unique: `(run_id, keyword, model_id)`

### `recommendations`
Final shortlist for a run.

- `id` UUID PK
- `run_id` FK
- `rank` int
- `keyword`, `model_id`
- `report_json` (final output payload)
- Unique: `(run_id, rank)`

### `http_cache`
Raw response cache to avoid repeat hits.

- `id` UUID PK
- `url`
- `request_hash` (method+url+params+headers)
- `status_code`
- `headers_json`
- `content_type`
- `body_bytes`
- `fetched_at`
- `expires_at`
- Unique: `(url, request_hash)`

---

## Scoring model (0–100)

Weights (env-configurable, must sum to 1.0):

- Trend strength: **0.25**
- Relevance: **0.20**
- MakerWorld popularity: **0.20**
- Freshness: **0.05**
- Printability: **0.20**
- Blind-box fit: **0.10**

### Factor scoring (examples)

- **Trend (0–100)**:
  - increase in interest over the last 7 days vs baseline
  - “Breakout” / high-rising related queries boost

- **Relevance (0–100)**:
  - fuzzy match between keyword and title/tags
  - token overlap bonus

- **Popularity (0–100)**:
  - log-scaled likes/downloads/makes

- **Freshness (0–100)**:
  - published within last 30 days → 100
  - within 90 days → 60
  - older → down to 0

- **Printability (0–100)**:
  - penalties for supports, fragility, multi-part builds
  - time/material target compliance boosts

- **Blind-box fit (0–100)**:
  - preferred categories (fidget/figurine/mini-toy)
  - small + cute + collectible language boost
  - “utility” models reduced

### Verdict mapping

- `DO` if:
  - hard constraints pass AND
  - `total >= 75`
- `MAYBE` if:
  - hard constraints pass AND
  - `60 <= total < 75`
- `SKIP` otherwise

---

## Print time + material estimation assumptions

Used when MakerWorld does not provide a slicer estimate:

- Printer: “common consumer FDM”
- Layer height: 0.20mm
- Walls: 2
- Top/bottom: 4 layers
- Infill: 15%
- Material: PLA density 1.24 g/cm³

Heuristic:

1. Estimate bounding box volume from `max_dimension_mm³`.
2. Multiply by a **geometry fill ratio** (category-dependent) that roughly models:
   - empty space / silhouette
   - infill + shell fraction

Default ratios (already include infill/shell effect):
- fidget: 0.030
- mini-toy: 0.025
- figurine: 0.020
- utility: 0.040
- other: 0.025

Then:

- `grams_est = bbox_volume_cm3 * 1.24 * fill_ratio`
- `time_minutes_est = 10 + grams_est * 6`

Uncertainty band: **±30%** (reported in notes).

Scaling:
- If `max_dimension_mm > 80` and `<= 110`, the estimator tries scaling down to 80mm.
- `grams` and `time` scale roughly with `scale_factor³`.

---

## Safety / kid-friendly filtering

Hard rejects if title/tags/description match:
- adult/explicit
- gore-heavy
- political propaganda
- hate/harassment terms
- weapons or weapon parts
- “dangerous functional” objects

Borderline “spooky” seasonal items may be allowed but flagged `manual_review_required`.

---

## Idempotency

A `run_id` groups one execution. Unique constraints prevent duplicate inserts for the same run.

---

## MakerWorld access and compliance

This codebase intentionally keeps MakerWorld access behind an adapter interface.

- Use the **dataset adapter** if scraping is disallowed or blocked.
- Enable the **web adapter** only after reviewing MakerWorld rules/robots and confirming access is permitted.
