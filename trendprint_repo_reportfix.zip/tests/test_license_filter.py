from app.pipeline.license import check_commercial_license


def test_license_allows_cc_by():
    dec = check_commercial_license("CC BY 4.0")
    assert dec.allowed is True


def test_license_rejects_nc():
    dec = check_commercial_license("CC BY-NC")
    assert dec.allowed is False
    assert dec.reason == "noncommercial_license"


def test_license_rejects_ambiguous():
    dec = check_commercial_license("Standard License")
    assert dec.allowed is False
