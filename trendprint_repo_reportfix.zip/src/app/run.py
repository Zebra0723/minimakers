from __future__ import annotations

from pathlib import Path

import typer

from app.config import get_settings
from app.db.session import make_session_factory
from app.logging_utils import configure_logging, get_logger
from app.notifier.report import write_reports
from app.notifier.webhook import notify_webhooks
from app.pipeline.orchestrator import PipelineRunner

log = get_logger(__name__)


def main(
    region: str = typer.Option(None, "--region", help="Market/region (default from env)."),
    limit: int = typer.Option(25, "--limit", help="Number of shortlisted items to output."),
    output: Path = typer.Option(Path("reports"), "--output", help="Output directory for reports."),
):
    settings = get_settings()
    configure_logging(settings.log_level)

    region_final = region or settings.default_region
    output_dir = output

    SessionFactory = make_session_factory(settings)
    runner = PipelineRunner(settings)

    # Keep the DB session open while writing the report so the Markdown can
    # include real trend/keyword/search context from this run.
    with SessionFactory() as session:
        run_id, items = runner.run_once(session, region=region_final, limit=limit, output_dir=output_dir)
        paths = write_reports(items, output_dir, region=region_final, run_id=run_id, session=session)

    log.info(
        "run_complete",
        extra={
            "run_id": run_id,
            "region": region_final,
            "shortlisted": len(items),
            "json_report": str(paths["json"]),
            "md_report": str(paths["md"]),
        },
    )

    notify_webhooks(
        items,
        region=region_final,
        slack_url=str(settings.slack_webhook_url) if settings.slack_webhook_url else None,
        discord_url=str(settings.discord_webhook_url) if settings.discord_webhook_url else None,
    )

    typer.echo(f"Run {run_id} complete. Reports: {paths['json']} , {paths['md']}")


if __name__ == "__main__":
    typer.run(main)
