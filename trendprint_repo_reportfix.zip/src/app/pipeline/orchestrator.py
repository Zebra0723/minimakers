from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from app.config import Settings
from app.db.models import Keyword, MakerWorldResult, ModelScore, Recommendation, Run, TrendSnapshot
from app.http_client import CachedHttpClient
from app.keywords.normalizer import KeywordNormalizer
from app.logging_utils import get_logger
from app.makerworld.adapter_base import MakerWorldSearchAdapter, MakerWorldSearchResult
from app.makerworld.dataset_adapter import MakerWorldDatasetAdapter
from app.makerworld.web_adapter import MakerWorldWebAdapter
from app.pipeline.classifier import classify_model
from app.pipeline.constraints import check_blind_box_constraints
from app.pipeline.estimation import estimate_printability
from app.pipeline.filtering import evaluate_content
from app.pipeline.license import check_commercial_license
from app.pipeline.scoring import (
    score_blind_box_fit,
    score_freshness,
    score_popularity,
    score_printability,
    score_relevance,
    score_trend,
    score_trend_relevance_confidence,
    total_score,
)
from app.schemas import RecommendationItem, ScoreBreakdown, TrendInfo
from app.trends.google_trends import GoogleTrendsIngestor, TrendKeyword

log = get_logger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def build_makerworld_adapter(session: Session, settings: Settings) -> MakerWorldSearchAdapter:
    if settings.makerworld_adapter.lower() == "web":
        http = CachedHttpClient(
            session=session,
            user_agent=settings.user_agent,
            requests_per_minute=settings.makerworld_requests_per_minute,
        )
        return MakerWorldWebAdapter(
            http=http,
            base_url=settings.makerworld_base_url,
            ttl_seconds=settings.makerworld_http_cache_ttl_seconds,
            scraping_allowed=settings.makerworld_scraping_allowed,
            user_agent=settings.user_agent,
        )
    # default
    return MakerWorldDatasetAdapter(dataset_path=settings.makerworld_dataset_path)


def _safe_int(x: Any) -> int:
    try:
        return int(x)
    except Exception:
        return 0


def _filament_cost_note(grams: float) -> str:
    # Rough UK assumption: £20/kg PLA => £0.02/g
    cost_gbp = grams * 0.02
    return f"filament_cost_est:~£{cost_gbp:.2f} (assumes £20/kg PLA)"


def _why_it_sells_notes(
    *,
    trend: TrendKeyword,
    model_stats: dict[str, Any],
    est_minutes: int,
    est_grams: float,
    supports: bool,
) -> list[str]:
    notes: list[str] = []
    if trend.momentum_score >= 80:
        notes.append(f"trend_breakout_signal:{trend.momentum_score:.0f}/100")
    elif trend.momentum_score >= 50:
        notes.append(f"trend_rising:{trend.momentum_score:.0f}/100")
    else:
        notes.append(f"trend_signal:{trend.momentum_score:.0f}/100")

    if trend.evidence:
        notes.append("trend_related_queries:" + "; ".join(trend.evidence[:5]))

    likes = _safe_int(model_stats.get("likes", 0))
    downloads = _safe_int(model_stats.get("downloads", 0))
    makes = _safe_int(model_stats.get("makes", 0))
    notes.append(f"model_popularity:likes={likes},downloads={downloads},makes={makes}")

    notes.append(f"print_estimate:{est_minutes}min,{est_grams:.1f}g")
    notes.append("printability:likely_supportless" if not supports else "printability:likely_supports (penalized)")

    return notes


class PipelineRunner:
    def __init__(self, settings: Settings):
        self.settings = settings

    def run_once(
        self,
        session: Session,
        *,
        region: str,
        limit: int,
        output_dir: Path,
    ) -> tuple[str, list[RecommendationItem]]:
        adapter: MakerWorldSearchAdapter | None = None

        run = Run(region=region, status="running", started_at=_utcnow())
        session.add(run)
        session.commit()

        run_id = run.id
        log.info("run_started", extra={"run_id": run_id, "region": region})

        try:
            ingestor = GoogleTrendsIngestor(
                hl=self.settings.google_trends_hl,
                tz=self.settings.google_trends_tz,
                geo=self.settings.google_trends_geo,
                timeframe=self.settings.trends_timeframe,
            )


            try:
                trends = ingestor.fetch(
                    region=region,
                    top_k=self.settings.trends_top_k,
                    related_top_k=self.settings.related_queries_top_k,
                )
            except Exception as e:
                log.warning("trends_fetch_failed", extra={"region": region, "error": str(e)})
                trends = []
                run.status = "partial"
                run.error_message = f"trends_fetch_failed: {e}"
                session.add(run)
                session.commit()

            # Store trend snapshots
            for t in trends:
                session.add(
                    TrendSnapshot(
                        run_id=run_id,
                        region=region,
                        keyword=t.keyword,
                        momentum_score=float(t.momentum_score),
                        evidence_json={"evidence": t.evidence},
                        raw_json=t.raw,
                    )
                )
            session.commit()

            # Normalize keywords
            normalizer = KeywordNormalizer()
            normalized = normalizer.normalize_keywords([t.keyword for t in trends])

            # Store normalized keywords
            for nk in normalized:
                session.add(
                    Keyword(
                        run_id=run_id,
                        source_keyword=nk.source_keyword,
                        normalized_keyword=nk.normalized_keyword,
                        expansions_json={
                            "expansions": nk.expansions,
                            "manual_review_required": nk.manual_review_required,
                            "rejected_reason": nk.rejected_reason,
                        },
                    )
                )
            session.commit()

            adapter = build_makerworld_adapter(session, self.settings)

            candidates: list[RecommendationItem] = []

            # Map source keyword -> TrendKeyword
            trend_map: dict[str, TrendKeyword] = {t.keyword: t for t in trends}

            for nk in normalized:
                if nk.rejected_reason:
                    continue

                trend = trend_map.get(nk.source_keyword) or TrendKeyword(
                    keyword=nk.source_keyword, momentum_score=0.0, evidence=[], raw=None
                )

                # Search for each expansion; merge results by model_id
                combined: dict[str, MakerWorldSearchResult] = {}
                for q in nk.expansions or [nk.normalized_keyword]:
                    try:
                        results = adapter.search(q, limit=25)
                    except Exception as e:
                        log.warning("makerworld_search_exception", extra={"keyword": q, "error": str(e)})
                        results = []
                    for r in results:
                        if r.model_id not in combined:
                            combined[r.model_id] = r
                        else:
                            prev = combined[r.model_id]
                            # Keep the one with richer info (license/stats)
                            if (not prev.license and r.license) or (prev.stats is None and r.stats is not None):
                                combined[r.model_id] = r

                if not combined:
                    continue

                for model_id, r in combined.items():
                    # Fetch detailed model
                    try:
                        model = adapter.fetch_details(r)
                    except Exception as e:
                        log.warning("makerworld_fetch_details_exception", extra={"model_id": model_id, "error": str(e)})
                        from app.schemas import MakerWorldModel as MWModel, ModelStats

                        model = MWModel(
                            title=r.title,
                            makerworld_url=r.makerworld_url,
                            creator=r.creator or "",
                            license=r.license or "",
                            tags=r.tags or [],
                            stats=r.stats or ModelStats(),
                            description="",
                            model_id=r.model_id,
                            published_at=r.published_at,
                        )

                    # Content safety filter
                    content_dec = evaluate_content(model.title, model.description, model.tags)
                    content_ok = content_dec.allowed

                    # License gate
                    lic_dec = check_commercial_license(model.license, allow_membership=False)
                    license_ok = lic_dec.allowed

                    # Classify
                    cls = classify_model(model.title, model.description, model.tags)

                    # Printability estimate
                    pr = estimate_printability(
                        model, cls_type=cls.type, max_dimension_mm_target=self.settings.max_dimension_mm
                    )

                    # Trend → model relevance confidence (semantic-ish)
                    trend_relevance_conf = score_trend_relevance_confidence(
                        nk.normalized_keyword,
                        model,
                        trend_evidence=list(trend.evidence or []),
                    )

                    # Hard constraints check
                    constraints = check_blind_box_constraints(
                        pr.estimate,
                        settings=self.settings,
                        supports_ok=(not pr.estimate.supports_likely),
                        content_ok=content_ok,
                        license_ok=license_ok,
                        durability_ok=pr.durability_ok,
                        scaling_ok=pr.scaling_ok,
                    )

                    # Compute scoring (even if rejected; stored for audit)
                    manual_review_required = nk.manual_review_required or pr.manual_review_required or content_dec.manual_review_required

                    relevance_score = score_relevance(
                        nk.normalized_keyword, model, trend_evidence=list(trend.evidence or [])
                    )

                    breakdown = ScoreBreakdown(
                        trend=score_trend(trend.momentum_score),
                        relevance=relevance_score,
                        trend_relevance_confidence=trend_relevance_conf,
                        popularity=score_popularity(model),
                        freshness=score_freshness(model),
                        printability=score_printability(pr.estimate, self.settings),
                        blind_box_fit=score_blind_box_fit(model, cls, pr.estimate, manual_review_required=manual_review_required),
                    )
                    breakdown.total = total_score(breakdown, self.settings)

                    # Additional noise reduction gates (keeps results "quiet")
                    # NOTE: We keep the score row for audit, but we do not allow
                    # low-confidence trend matches or obvious utilities to surface.
                    rejected_reasons = list(constraints.reasons)
                    constraints_passed = constraints.passed

                    if cls.type == "utility":
                        rejected_reasons.append("utility_model_excluded")
                        constraints_passed = False

                    # Hard exclude a few common non-blind-box categories even when
                    # they are small (e.g., tiny vases / mounts still aren't a good
                    # blind-box for 10–11-year-olds).
                    text = " ".join([model.title, model.description, " ".join(model.tags or [])]).lower()
                    tokens = set(re.findall(r"[a-z0-9]+", text))
                    hard_non_blindbox_terms = [
                        "lithophane",
                        "vase",
                        "planter",
                        "lamp",
                        "lampshade",
                        "shade",
                        "wall art",
                        "sign",
                        "coaster",
                        "mount",
                        "bracket",
                        "holder",
                        "organizer",
                        "replacement",
                    ]
                    def _term_present(term: str) -> bool:
                        return term in text if " " in term else term in tokens

                    if any(_term_present(t) for t in hard_non_blindbox_terms):
                        rejected_reasons.append("non_blindbox_category")
                        constraints_passed = False

                    if trend_relevance_conf < float(self.settings.min_trend_relevance_confidence):
                        rejected_reasons.append(f"low_trend_relevance_confidence:{trend_relevance_conf:.0f}")
                        constraints_passed = False
                    if relevance_score < float(self.settings.min_relevance_score):
                        rejected_reasons.append(f"low_relevance_score:{relevance_score:.0f}")
                        constraints_passed = False

                    # Verdict
                    verdict = "SKIP"
                    if constraints_passed and breakdown.total >= 80:
                        verdict = "DO"
                    elif constraints_passed and breakdown.total >= 68:
                        verdict = "MAYBE"

                    # Persist MakerWorld result (per keyword)
                    try:
                        session.add(
                            MakerWorldResult(
                                run_id=run_id,
                                keyword=nk.normalized_keyword,
                                model_id=str(model.model_id or model_id),
                                makerworld_url=model.makerworld_url,
                                title=model.title or "",
                                description=model.description or "",
                                creator=model.creator or "",
                                license=model.license or "",
                                tags_json=list(model.tags or []),
                                stats_json={
                                    "likes": int(model.stats.likes),
                                    "downloads": int(model.stats.downloads),
                                    "makes": int(model.stats.makes),
                                },
                                published_at=model.published_at,
                                raw_json=r.raw,
                            )
                        )
                        session.commit()
                    except Exception:
                        session.rollback()

                    notes: list[str] = []
                    notes.extend(
                        _why_it_sells_notes(
                            trend=trend,
                            model_stats={
                                "likes": int(model.stats.likes),
                                "downloads": int(model.stats.downloads),
                                "makes": int(model.stats.makes),
                            },
                            est_minutes=pr.estimate.time_minutes_est,
                            est_grams=pr.estimate.grams_est,
                            supports=pr.estimate.supports_likely,
                        )
                    )
                    notes.append(_filament_cost_note(pr.estimate.grams_est))
                    notes.append(f"license_check:{lic_dec.reason} ({model.license or 'unknown'})")
                    notes.append(f"trend_relevance_confidence:{trend_relevance_conf:.0f}/100")

                    # Persist reject reasons into notes for *all* models (including SKIP)
                    # so the daily Markdown report can summarize why candidates were
                    # filtered out without requiring a DB schema migration.
                    if rejected_reasons:
                        notes.append("rejected_reasons:" + ";".join(rejected_reasons))

                    if content_dec.reasons:
                        notes.append("content_flags:" + "; ".join(content_dec.reasons[:6]))
                    if pr.notes:
                        notes.extend(pr.notes[:6])

                    if nk.manual_review_required:
                        notes.append("manual_review:trend_keyword_flagged")
                    if pr.manual_review_required or content_dec.manual_review_required:
                        notes.append("manual_review:model_flagged")

                    item = RecommendationItem(
                        keyword=nk.normalized_keyword,
                        trend=TrendInfo(
                            region=region,
                            source="google_trends",
                            momentum_score=float(trend.momentum_score),
                            evidence=list(trend.evidence or [])[: self.settings.related_queries_top_k],
                        ),
                        model=model,
                        classification=cls,
                        print_estimate=pr.estimate,
                        scores=breakdown,
                        verdict=verdict,  # type: ignore[arg-type]
                        notes=notes[:20],
                        manual_review_required=manual_review_required,
                        rejected_reasons=rejected_reasons,
                        uncertainty="±30% time/material estimate when slicer data unavailable",
                    )

                    # Store score row
                    try:
                        session.add(
                            ModelScore(
                                run_id=run_id,
                                keyword=nk.normalized_keyword,
                                model_id=str(model.model_id or model_id),
                                total_score=float(round(breakdown.total, 2)),
                                verdict=verdict,
                                scores_json=item.scores.model_dump(),
                                notes_json=item.notes,
                            )
                        )
                        session.commit()
                    except Exception:
                        session.rollback()

                    # Only shortlist DO/MAYBE (hard constraints must pass)
                    if verdict in {"DO", "MAYBE"}:
                        candidates.append(item)

            # Rank and select top N
            candidates.sort(key=lambda x: x.scores.total, reverse=True)
            top_n = candidates[: max(0, int(limit))]

            # Persist recommendations
            for idx, item in enumerate(top_n, start=1):
                try:
                    session.add(
                        Recommendation(
                            run_id=run_id,
                            rank=idx,
                            keyword=item.keyword,
                            model_id=str(item.model.model_id or ""),
                            report_json=item.model_dump(),
                        )
                    )
                    session.commit()
                except Exception:
                    session.rollback()

            # Finalize run
            run.status = "success"
            run.finished_at = _utcnow()
            session.add(run)
            session.commit()

            return run_id, top_n

        except Exception as e:
            session.rollback()
            run.status = "error"
            run.finished_at = _utcnow()
            run.error_message = str(e)
            session.add(run)
            session.commit()
            log.exception("run_failed", extra={"run_id": run_id, "error": str(e)})
            raise

        finally:
            # Close http client if web adapter was used
            try:
                if adapter and hasattr(adapter, "http") and getattr(adapter, "http") is not None:  # type: ignore[attr-defined]
                    getattr(adapter, "http").close()  # type: ignore[attr-defined]
            except Exception:
                pass
