from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any

from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type

from pytrends.request import TrendReq

from app.logging_utils import get_logger


log = get_logger(__name__)


class GoogleTrendsError(RuntimeError):
    pass


@dataclass(frozen=True)
class TrendKeyword:
    keyword: str
    momentum_score: float
    evidence: list[str]
    raw: dict[str, Any] | None = None


_REGION_TO_PN = {
    "UK": "united_kingdom",
    "GB": "united_kingdom",
    "UNITED KINGDOM": "united_kingdom",
}


def _pn_for_region(region: str) -> str:
    return _REGION_TO_PN.get(region.strip().upper(), "united_kingdom")


@retry(
    reraise=True,
    stop=stop_after_attempt(4),
    wait=wait_exponential_jitter(initial=1, max=20),
    retry=retry_if_exception_type(Exception),
)
def _safe_trending_searches(pytrends: TrendReq, pn: str):
    # pytrends internally uses requests; transient failures can throw a wide set of exceptions.
    return pytrends.trending_searches(pn=pn)


@retry(
    reraise=True,
    stop=stop_after_attempt(4),
    wait=wait_exponential_jitter(initial=1, max=20),
    retry=retry_if_exception_type(Exception),
)
def _safe_related(pytrends: TrendReq):
    return pytrends.related_queries()


@retry(
    reraise=True,
    stop=stop_after_attempt(4),
    wait=wait_exponential_jitter(initial=1, max=20),
    retry=retry_if_exception_type(Exception),
)
def _safe_interest_over_time(pytrends: TrendReq):
    return pytrends.interest_over_time()


class GoogleTrendsIngestor:
    '''
    Fetches trending searches + related queries and computes a momentum score.

    This is *best-effort* because Google Trends is not an official public API.
    Handle rate limiting & retries, and degrade gracefully if some calls fail.
    '''

    def __init__(self, hl: str = "en-GB", tz: int = 0, geo: str = "GB", timeframe: str = "now 7-d"):
        self.hl = hl
        self.tz = tz
        self.geo = geo
        self.timeframe = timeframe

    def _client(self) -> TrendReq:
        return TrendReq(hl=self.hl, tz=self.tz, retries=0, backoff_factor=0)

    def fetch(self, region: str, top_k: int = 50, related_top_k: int = 10) -> list[TrendKeyword]:
        pn = _pn_for_region(region)
        pytrends = self._client()

        try:
            df = _safe_trending_searches(pytrends, pn=pn)
        except Exception as e:
            raise GoogleTrendsError(f"Failed to fetch trending searches for region={region}: {e}") from e

        # DataFrame has one column: 0
        keywords = [str(x) for x in df.iloc[:, 0].tolist()][:top_k]
        results: list[TrendKeyword] = []

        for kw in keywords:
            # Small jitter between calls to reduce throttling probability
            time.sleep(random.uniform(0.4, 1.1))

            evidence: list[str] = []
            momentum = 0.0
            raw: dict[str, Any] = {}

            try:
                pytrends.build_payload([kw], timeframe=self.timeframe, geo=self.geo)
                rq = _safe_related(pytrends)
                raw["related_queries"] = {}

                # rq is dict[term, {"top": df, "rising": df}]
                term_data = rq.get(kw) or {}
                top_df = term_data.get("top")
                rising_df = term_data.get("rising")

                if rising_df is not None and len(rising_df) > 0:
                    rising_terms = []
                    for _, row in rising_df.head(related_top_k).iterrows():
                        q = str(row.get("query", "")).strip()
                        v = row.get("value", None)
                        if q:
                            rising_terms.append(q)
                            # Value can be "Breakout" or a percentage int
                            if isinstance(v, str) and v.lower().strip() == "breakout":
                                momentum = max(momentum, 100.0)
                            elif isinstance(v, (int, float)):
                                # map 0..5000-ish to 0..100 (cap)
                                momentum = max(momentum, min(100.0, float(v) / 50.0))
                    evidence.extend(rising_terms)
                    raw["related_queries"]["rising"] = rising_df.head(related_top_k).to_dict(orient="records")

                if top_df is not None and len(top_df) > 0:
                    top_terms = [str(x) for x in top_df["query"].head(related_top_k).tolist() if str(x).strip()]
                    evidence.extend([t for t in top_terms if t not in evidence])
                    raw["related_queries"]["top"] = top_df.head(related_top_k).to_dict(orient="records")

                # Interest over time can give extra signal; compute slope-ish
                try:
                    iot = _safe_interest_over_time(pytrends)
                    if iot is not None and len(iot) >= 3 and kw in iot.columns:
                        series = iot[kw].astype(float)
                        # Simple momentum: last value vs median of previous values
                        last = float(series.iloc[-1])
                        baseline = float(series.iloc[:-1].median()) if len(series) > 1 else last
                        if baseline > 0:
                            rel = (last - baseline) / baseline
                            momentum = max(momentum, min(100.0, max(0.0, rel * 100.0)))
                        raw["interest_over_time_tail"] = series.tail(10).to_dict()
                except Exception as e:
                    log.warning("interest_over_time_failed", extra={"keyword": kw, "error": str(e)})

            except Exception as e:
                log.warning("related_query_failed", extra={"keyword": kw, "error": str(e)})

            results.append(
                TrendKeyword(
                    keyword=kw,
                    momentum_score=float(momentum),
                    evidence=evidence[:related_top_k],
                    raw=raw if raw else None,
                )
            )

        return results
