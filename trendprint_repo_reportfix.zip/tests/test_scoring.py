from datetime import datetime, timezone

from app.config import Settings
from app.schemas import MakerWorldModel, ModelStats, PrintEstimate, Classification, ScoreBreakdown
from app.pipeline.scoring import (
    score_trend,
    score_relevance,
    score_popularity,
    score_freshness,
    score_printability,
    score_blind_box_fit,
    total_score,
)


def test_scores_in_range():
    settings = Settings(DATABASE_URL="sqlite:///:memory:")

    model = MakerWorldModel(
        title="Clicky Print-in-Place Fidget Slider",
        makerworld_url="https://makerworld.com/en/models/123456-clicky-slider",
        creator="test",
        license="CC BY",
        tags=["fidget", "print in place", "toy"],
        stats=ModelStats(likes=120, downloads=2400, makes=50),
        description="A small clicky slider desk fidget.",
        model_id="123456",
        published_at=datetime.now(timezone.utc),
    )

    est = PrintEstimate(max_dimension_mm=60, grams_est=12.0, time_minutes_est=45, supports_likely=False)
    cls = Classification(type="fidget", confidence=0.9)

    breakdown = ScoreBreakdown(
        trend=score_trend(80),
        relevance=score_relevance("fidget", model),
        popularity=score_popularity(model),
        freshness=score_freshness(model),
        printability=score_printability(est, settings),
        blind_box_fit=score_blind_box_fit(model, cls, est, manual_review_required=False),
    )
    breakdown.total = total_score(breakdown, settings)

    assert 0 <= breakdown.total <= 100
    assert breakdown.relevance >= 60
    assert breakdown.printability > 50
