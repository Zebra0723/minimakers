from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class ContentDecision:
    allowed: bool
    manual_review_required: bool
    reasons: list[str]


def _norm(text: str) -> str:
    return " ".join((text or "").lower().replace("’", "'").split())


# Hard reject for kids / mainstream
_HARD_BANNED = {
    # Adult
    "nsfw",
    "nude",
    "porn",
    "porno",
    "sex",
    "sexy",
    "erotic",
    "hentai",
    "lingerie",
    # Gore / extreme
    "gore",
    "entrails",
    "dismember",
    "decapitat",  # prefix match via 'in'
    # Weapons / dangerous
    "gun",
    "pistol",
    "rifle",
    "shotgun",
    "ammo",
    "ammunition",
    "bullet",
    "knife",
    "dagger",
    "sword",
    "katana",
    "grenade",
    "bomb",
    "explosive",
    "silencer",
    "suppressor",
    "weapon",
    # Dangerous functional items
    "lockpick",
    "lock pick",
    "brass knuckle",
    "switchblade",
    "taser",
    # Political / propaganda
    "election",
    "vote",
    "brexit",
    "maga",
    "labour party",
    "conservative party",
    "ukip",
    "reform uk",
}

# Soft flags: allow but ask for manual review (tone/content/IP)
_SOFT_FLAGS = {
    "skull",
    "skeleton",
    "zombie",
    "blood",
    "horror",
    "creepy",
    "monster",
    "demon",
    "satan",
    "poop",
    "toilet",
}

# Soft flags for IP/trademark risk (license is not a guarantee of rights to the character/brand)
_IP_RISK = {
    "pokemon",
    "pokémon",
    "minecraft",
    "lego",
    "disney",
    "marvel",
    "star wars",
    "harry potter",
    "sonic",
    "mario",
    "hello kitty",
    "fortnite",
}


def evaluate_content(title: str, description: str, tags: list[str]) -> ContentDecision:
    text = _norm(" ".join([title or "", description or "", " ".join(tags or [])]))

    reasons: list[str] = []
    manual = False

    for term in _HARD_BANNED:
        if term in text:
            reasons.append(f"hard_banned_term:{term}")
    if reasons:
        return ContentDecision(allowed=False, manual_review_required=False, reasons=reasons)

    for term in _SOFT_FLAGS:
        if term in text:
            manual = True
            reasons.append(f"soft_flag_term:{term}")

    for term in _IP_RISK:
        if term in text:
            manual = True
            reasons.append(f"ip_risk_term:{term}")

    return ContentDecision(allowed=True, manual_review_required=manual, reasons=reasons)


def is_mainstream_safe_for_kids(title: str, description: str, tags: list[str]) -> bool:
    # Convenience wrapper
    return evaluate_content(title, description, tags).allowed
