from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone

import re

from rapidfuzz import fuzz

from app.config import Settings
from app.schemas import Classification, MakerWorldModel, PrintEstimate, ScoreBreakdown


def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def score_trend(momentum_score: float) -> float:
    return _clamp(float(momentum_score))


# --- Relevance / confidence ---
# The v1 implementation relied on string fuzzing only. In practice that allowed
# a lot of false positives where a high-momentum trend accidentally matched a
# loosely related model (e.g., news/event/celebrity queries).
#
# v2 introduces a "trend relevance confidence" signal:
#   - productizable_confidence: does the trend look like something with a physical
#     printable analogue (vs. pure news/event intent)?
#   - concept_match_confidence: do the *meaningful tokens* from the trend appear in
#     the model title/tags (not just the description)?
# We multiply these into relevance so low-confidence matches fall out of the top.

_WORD_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)

_STOPWORDS = {
    # Core English stopwords
    "the",
    "a",
    "an",
    "and",
    "or",
    "of",
    "for",
    "in",
    "on",
    "at",
    "to",
    "from",
    "with",
    "by",
    "as",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    "it",
    "this",
    "that",
    "these",
    "those",
    "my",
    "your",
    "our",
    "their",
    "me",
    "you",
    "we",
    "they",
    "i",
    "he",
    "she",
    "them",
    "his",
    "her",
    "its",
    "what",
    "who",
    "when",
    "where",
    "why",
    "how",
    # Common query glue
    "vs",
    "v",
    "near",
    "me",
    "today",
    "now",
    "latest",
    "new",
    "uk",
    "gb",
    "england",
    "britain",
    "british",
    # Dates/months
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
}

# Keywords that frequently indicate "this is a news/event query", not a product
# concept you can turn into a blind-box print.
_EVENT_NEWSY_TERMS = {
    "live",
    "stream",
    "watch",
    "tickets",
    "match",
    "fixture",
    "score",
    "result",
    "results",
    "highlights",
    "news",
    "latest",
    "update",
    "episode",
    "season",
    "trailer",
    "release",
    "date",
    "net",
    "worth",
    "age",
    "height",
    "girlfriend",
    "boyfriend",
    "wife",
    "husband",
    "lyrics",
    "meaning",
}

_PHYSICAL_HINT_TERMS = {
    "toy",
    "fidget",
    "figurine",
    "figure",
    "mini",
    "charm",
    "keychain",
    "keyring",
    "keycap",
    "desk",
    "collectible",
}


def _tokenize(text: str) -> list[str]:
    if not text:
        return []
    toks = [t.lower() for t in _WORD_RE.findall(text.lower())]
    out: list[str] = []
    for t in toks:
        # Drop pure numbers (years, dates, rankings) to focus on concept words.
        if t.isdigit():
            continue
        if len(t) == 4 and t.startswith("20") and t.isdigit():
            continue
        if t in _STOPWORDS:
            continue
        if len(t) <= 1:
            continue
        out.append(t)
    return out


def _productizable_confidence(keyword: str, trend_evidence: list[str] | None = None) -> float:
    """Heuristic confidence (0..100) that a trend maps to a sellable physical print."""

    blob = " ".join([keyword or "", " ".join(trend_evidence or [])]).lower()
    tokens = set(_tokenize(blob))

    conf = 100.0

    # Strong event indicator: "A vs B". These are almost always match/event intent.
    if " vs " in f" {blob} " or re.search(r"\bvs\b", blob) or re.search(r"\bv\b", blob):
        conf *= 0.25

    # Newsy / celebrity-query intent.
    if tokens.intersection(_EVENT_NEWSY_TERMS):
        conf *= 0.60

    # Queries that are usually service/info, not product concepts.
    if "near me" in blob or "how to" in blob or "what is" in blob:
        conf *= 0.50

    # If we see explicit physical-product hint terms, we can recover some confidence.
    if tokens.intersection(_PHYSICAL_HINT_TERMS):
        conf = min(100.0, conf + 20.0)

    return _clamp(conf)


def _concept_match_confidence(keyword: str, model: MakerWorldModel) -> float:
    """Heuristic confidence (0..100) that the model conceptually matches the keyword."""

    kw_tokens = _tokenize(keyword)
    if not kw_tokens:
        return 0.0

    title = (model.title or "")
    tags = " ".join(model.tags or [])
    desc = (model.description or "")

    title_tokens = set(_tokenize(title))
    tag_tokens = set(_tokenize(tags))
    desc_tokens = set(_tokenize(desc))

    matched_weight = 0.0
    total_weight = 0.0
    for tok in kw_tokens:
        # Longer / more specific tokens count a bit more.
        w = 1.0 + min(1.0, max(0.0, (len(tok) - 4) / 6.0))
        total_weight += w

        variants = {tok}
        if tok.endswith("s") and len(tok) > 3:
            variants.add(tok[:-1])

        if variants.intersection(title_tokens) or variants.intersection(tag_tokens):
            matched_weight += w
        elif variants.intersection(desc_tokens):
            # Description-only matches are weaker (often incidental).
            matched_weight += 0.5 * w

    if total_weight <= 0:
        return 0.0
    return _clamp(100.0 * (matched_weight / total_weight))


def score_trend_relevance_confidence(
    keyword: str,
    model: MakerWorldModel,
    *,
    trend_evidence: list[str] | None = None,
) -> float:
    """Combined confidence (0..100) that this trend keyword maps to this model."""

    p = _productizable_confidence(keyword, trend_evidence)
    m = _concept_match_confidence(keyword, model)
    # Geometric mean: both must be high.
    conf = math.sqrt(max(0.0, p) * max(0.0, m))
    return _clamp(conf)


def score_relevance(keyword: str, model: MakerWorldModel, *, trend_evidence: list[str] | None = None) -> float:
    kw = keyword.lower().strip()
    title = (model.title or "").lower()
    tags = " ".join(model.tags or []).lower()
    desc = (model.description or "").lower()

    title_score = float(fuzz.token_set_ratio(kw, title))
    tag_score = float(fuzz.token_set_ratio(kw, tags)) if tags else 0.0
    desc_score = float(fuzz.partial_ratio(kw, desc)) if desc else 0.0

    # Prefer title & tags for relevance
    base = max(title_score, tag_score * 0.9, desc_score * 0.7)

    # Confidence-adjusted relevance.
    conf = score_trend_relevance_confidence(keyword, model, trend_evidence=trend_evidence)
    score = base * (conf / 100.0)

    return _clamp(score)


def score_popularity(model: MakerWorldModel) -> float:
    likes = max(0, int(model.stats.likes))
    downloads = max(0, int(model.stats.downloads))
    makes = max(0, int(model.stats.makes))

    # Log-scaled, saturating. Heuristic only.
    x = 0.55 * math.log1p(downloads) + 0.35 * math.log1p(likes) + 0.10 * math.log1p(makes)
    score = 100.0 * (1.0 - math.exp(-x / 5.0))
    return _clamp(score)


def score_freshness(model: MakerWorldModel) -> float:
    if not model.published_at:
        return 30.0
    now = datetime.now(timezone.utc)
    dt = model.published_at
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    age_days = max(0, (now - dt).days)
    if age_days <= 30:
        return 100.0
    if age_days <= 90:
        return 60.0
    if age_days <= 180:
        return 40.0
    if age_days <= 365:
        return 20.0
    return 10.0


def score_printability(est: PrintEstimate, settings: Settings) -> float:
    dim = float(est.max_dimension_mm or 0)
    grams = float(est.grams_est or 0)
    minutes = float(est.time_minutes_est or 0)

    # v2: sharper penalties near hard limits.
    # We want the top of the list to be *comfortably* under the blind-box targets,
    # not "just barely" under them.
    score = 100.0

    t_target = float(settings.max_print_time_minutes or 90)
    g_target = float(settings.max_filament_grams or 30)
    d_target = float(settings.max_dimension_mm or 80)

    t_ratio = minutes / t_target if t_target > 0 else 0.0
    g_ratio = grams / g_target if g_target > 0 else 0.0
    d_ratio = dim / d_target if d_target > 0 else 0.0

    # Quadratic penalties: low impact when small, steep near the cap.
    score -= 35.0 * (t_ratio ** 2)
    score -= 20.0 * (g_ratio ** 2)
    score -= 15.0 * (d_ratio ** 2)

    # Near-hard penalties (kicks in close to threshold).
    if t_ratio > 0.85:
        score -= 18.0 * (t_ratio - 0.85) / 0.15
    if g_ratio > 0.85:
        score -= 16.0 * (g_ratio - 0.85) / 0.15
    if d_ratio > 0.90:
        score -= 12.0 * (d_ratio - 0.90) / 0.10

    # Supports: still heavily penalized (and usually filtered out).
    if getattr(est, "supports_likely", False):
        score -= 35.0

    # Multi-part assemblies get a strong penalty.
    parts_est = int(getattr(est, "parts_est", 1) or 1)
    if parts_est == 2:
        score -= 12.0
    elif parts_est > 2:
        score -= 35.0

    # Scaling adds ops complexity and risk of detail loss.
    if getattr(est, "scaled_down", False):
        score -= 8.0
        sf = float(getattr(est, "scale_factor", 1.0) or 1.0)
        if sf < 0.85:
            score -= 10.0

    # Fragility risk (0..1) -> 0..40 penalty.
    frag = float(getattr(est, "fragility_risk", 0.0) or 0.0)
    score -= min(40.0, frag * 80.0)

    # External hardware is a hard operational negative.
    if getattr(est, "requires_hardware", False):
        score -= 60.0

    return _clamp(score)


def score_blind_box_fit(
    model: MakerWorldModel,
    cls: Classification,
    est: PrintEstimate,
    manual_review_required: bool,
) -> float:
    text = " ".join([model.title, model.description, " ".join(model.tags or [])]).lower()

    # v2: stronger bias toward collectible blind-box archetypes.
    if cls.type == "fidget":
        score = 92.0
    elif cls.type == "figurine":
        score = 82.0
    elif cls.type == "mini-toy":
        score = 80.0
    elif cls.type == "utility":
        score = 15.0
    else:
        score = 45.0

    # Bonuses
    bonuses = [
        # Fidgets
        ("slider", 6.0),
        ("clicker", 6.0),
        ("clicky", 6.0),
        ("ratchet", 6.0),
        ("spinner", 5.0),
        ("tactile", 4.0),
        ("haptic", 4.0),
        ("worry", 3.0),
        ("stress", 3.0),
        # Collectibles
        ("print in place", 6.0),
        ("print-in-place", 6.0),
        ("keychain", 5.0),
        ("keyring", 5.0),
        ("charm", 5.0),
        ("keycap", 5.0),
        ("cute", 4.0),
        ("mini", 3.0),
        ("chibi", 3.0),
        ("collectible", 4.0),
        ("desk buddy", 4.0),
        ("desk toy", 4.0),
        ("desk", 3.0),
    ]
    for term, b in bonuses:
        if term in text:
            score += b

    # Penalties
    # Non-blind-box categories/keywords: decor + tools.
    decor_terms = [
        "vase",
        "planter",
        "lithophane",
        "lamp",
        "shade",
        "wall art",
        "wallart",
        "sign",
        "coaster",
        "ornament",
        "tree topper",
    ]
    util_terms = ["holder", "mount", "bracket", "adapter", "case", "organizer", "replacement"]
    if any(t in text for t in decor_terms):
        score -= 20.0
    if any(t in text for t in util_terms):
        score -= 25.0

    if getattr(est, "supports_likely", False):
        score -= 15.0

    parts_est = int(getattr(est, "parts_est", 1) or 1)
    if parts_est == 2:
        score -= 10.0
    elif parts_est > 2:
        score -= 25.0

    if getattr(est, "scaled_down", False):
        score -= 8.0

    if getattr(est, "requires_hardware", False):
        score -= 35.0

    # Stronger near-hard penalties.
    if est.time_minutes_est > 75:
        score -= 10.0
    if est.grams_est > 22:
        score -= 10.0
    if est.max_dimension_mm > 70:
        score -= 8.0

    # Bonuses for being comfortably small/fast.
    if est.time_minutes_est <= 45:
        score += 4.0
    if est.grams_est <= 15:
        score += 4.0
    if est.max_dimension_mm <= 55:
        score += 3.0

    # Fragility risk: penalize even if it passed the hard gate.
    frag = float(getattr(est, "fragility_risk", 0.0) or 0.0)
    if frag >= 0.25:
        score -= 15.0
    elif frag >= 0.15:
        score -= 8.0

    # Lower confidence classifications are more likely to be mis-bucketed.
    if cls.confidence < 0.55:
        score -= 6.0
    if manual_review_required:
        score -= 15.0

    return _clamp(score)


def total_score(breakdown: ScoreBreakdown, settings: Settings) -> float:
    # Weighted sum of factor scores, returned as 0..100
    weights_sum = (
        settings.weight_trend
        + settings.weight_relevance
        + settings.weight_popularity
        + settings.weight_freshness
        + settings.weight_printability
        + settings.weight_blind_box_fit
    )
    if abs(weights_sum - 1.0) > 1e-6:
        # Normalize defensively
        w_trend = settings.weight_trend / weights_sum
        w_rel = settings.weight_relevance / weights_sum
        w_pop = settings.weight_popularity / weights_sum
        w_fresh = settings.weight_freshness / weights_sum
        w_print = settings.weight_printability / weights_sum
        w_bb = settings.weight_blind_box_fit / weights_sum
    else:
        w_trend = settings.weight_trend
        w_rel = settings.weight_relevance
        w_pop = settings.weight_popularity
        w_fresh = settings.weight_freshness
        w_print = settings.weight_printability
        w_bb = settings.weight_blind_box_fit

    total = (
        breakdown.trend * w_trend
        + breakdown.relevance * w_rel
        + breakdown.popularity * w_pop
        + breakdown.freshness * w_fresh
        + breakdown.printability * w_print
        + breakdown.blind_box_fit * w_bb
    )
    return _clamp(total)
