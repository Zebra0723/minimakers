# TrendPrint — UK Google Trends → MakerWorld → Blind-box-ready 3D print shortlist

TrendPrint is a small production-minded service that:

1. Pulls **emerging/trending topics** from **Google Trends (UK)**.
2. Normalizes and expands those topics into **searchable keywords**.
3. Searches **MakerWorld** for matching 3D models (via a swappable adapter).
4. Filters for **kid-friendly**, **mainstream**, **small/fast/cheap** prints suitable for a blind-box business.
5. Produces an explainable, ranked shortlist with:
   - trend evidence
   - model metadata + MakerWorld link
   - print time & filament estimates (with assumptions)
   - commercial licensing check (hard gate)
   - confidence score + DO/MAYBE/SKIP

> ⚠️ **Important**: MakerWorld access is adapter-based. Scraping may be restricted by MakerWorld terms/robots.  
> Default configuration uses a **local dataset adapter** (`MakerWorldDatasetAdapter`).  
> Enable the web adapter only if you have verified you are allowed to do so.

---

## Repo layout

- `docs/design.md` — tech design doc, schema, scoring, assumptions
- `src/app/` — service code
- `tests/` — unit tests
- `reports/` — example outputs (JSON + Markdown)
- `alembic/` — migrations
- `docker-compose.yml` — Postgres + app

---

## Quickstart (local)

### 1) Create a virtualenv + install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e ".[dev]"
```

### 2) Configure environment

Copy `.env.example` to `.env` and edit:

```bash
cp .env.example .env
```

Then export it (or use direnv):

```bash
export $(cat .env | xargs)
```

### 3) Start Postgres (recommended)

```bash
docker compose up -d db
```

Run migrations:

```bash
alembic upgrade head
```

### 4) Run a single pipeline execution

```bash
python -m app.run --region UK --limit 25 --output reports/
```

This writes:

- `reports/recommendations_YYYYMMDD_HHMM.json`
- `reports/recommendations_YYYYMMDD_HHMM.md`

---

## Running with Docker Compose

```bash
docker compose up --build
```

The app container runs the pipeline once (see `CMD` in `Dockerfile`).  
For a schedule, use one of the options below.

---

## Scheduling options

### Option A: Cron (simple, reliable)

Example: run every 4 hours:

```cron
0 */4 * * * cd /path/to/trendprint && /path/to/.venv/bin/python -m app.run --region UK --limit 25 --output reports/ >> logs/cron.log 2>&1
```

### Option B: Built-in scheduler (APScheduler-style loop)

```bash
python -m app.scheduler --region UK --limit 25 --output reports/ --every-minutes 240
```

---

## MakerWorld adapters

### Default: Dataset adapter (no scraping)

Set:

- `MAKERWORLD_ADAPTER=dataset`
- `MAKERWORLD_DATASET_PATH=data/makerworld_dataset.jsonl`

The dataset is a JSONL file with one model per line (see `docs/design.md`).

You can build this dataset **manually** (export if MakerWorld provides one) or from permitted sources.

### Optional: Web adapter (polite, cached)

Set:

- `MAKERWORLD_ADAPTER=web`
- `MAKERWORLD_SCRAPING_ALLOWED=true`

The adapter:
- checks `robots.txt` (best-effort)
- uses a low request rate + caching
- stores raw responses in `http_cache` to avoid re-hits

If access fails (login required / blocked / 4xx), the pipeline continues and produces trend-only output.

---

## Configuration (env vars)

See `.env.example` for full list.

Key ones:

- `DATABASE_URL` (e.g. `postgresql+psycopg2://postgres:postgres@db:5432/trendprint`)
- `DEFAULT_REGION=UK`
- `GOOGLE_TRENDS_GEO=GB`
- `MAKERWORLD_ADAPTER=dataset|web`
- `MAKERWORLD_SCRAPING_ALLOWED=false|true`
- `REPORT_TOP_N=25`
- `SLACK_WEBHOOK_URL` (optional)
- `DISCORD_WEBHOOK_URL` (optional)

---

## Tests

```bash
pytest -q
```

---

## License

MIT.
