from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from sqlalchemy import select, delete
from sqlalchemy.orm import Session

from app.db.models import HttpCache
from app.logging_utils import get_logger

log = get_logger(__name__)


@dataclass
class CachedResponse:
    url: str
    status_code: int
    headers: dict[str, str]
    content: bytes
    content_type: str

    @property
    def text(self) -> str:
        # best-effort decode
        try:
            return self.content.decode("utf-8", errors="replace")
        except Exception:
            return str(self.content)


class PoliteRateLimiter:
    '''
    Very small per-process rate limiter.
    For more advanced setups, replace with Redis-based token bucket.
    '''

    def __init__(self, requests_per_minute: int):
        self.rpm = max(1, int(requests_per_minute))
        self.min_interval = 60.0 / float(self.rpm)
        self._last = 0.0

    def wait(self) -> None:
        now = time.time()
        elapsed = now - self._last
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self._last = time.time()


class CachedHttpClient:
    def __init__(
        self,
        session: Session,
        *,
        user_agent: str,
        timeout_seconds: float = 20.0,
        requests_per_minute: int = 30,
    ):
        self.session = session
        self.rate_limiter = PoliteRateLimiter(requests_per_minute=requests_per_minute)
        self.client = httpx.Client(timeout=timeout_seconds, headers={"User-Agent": user_agent})

    def close(self) -> None:
        self.client.close()

    @staticmethod
    def _hash_request(method: str, url: str, params: dict[str, Any] | None, headers: dict[str, str] | None) -> str:
        payload = {"method": method.upper(), "url": url, "params": params or {}, "headers": headers or {}}
        s = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    def get(self, url: str, *, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None, ttl_seconds: int = 3600) -> CachedResponse:
        req_hash = self._hash_request("GET", url, params, headers)
        now = datetime.now(timezone.utc)

        # Clean expired cache rows occasionally (best-effort)
        try:
            self.session.execute(delete(HttpCache).where(HttpCache.expires_at < now))
            self.session.commit()
        except Exception:
            self.session.rollback()

        stmt = select(HttpCache).where(HttpCache.url == url, HttpCache.request_hash == req_hash, HttpCache.expires_at >= now)
        row = self.session.execute(stmt).scalar_one_or_none()
        if row is not None:
            return CachedResponse(
                url=row.url,
                status_code=row.status_code,
                headers={k: str(v) for k, v in (row.headers_json or {}).items()},
                content=row.body_bytes,
                content_type=row.content_type,
            )

        self.rate_limiter.wait()

        resp = self.client.get(url, params=params, headers=headers)
        content_type = resp.headers.get("content-type", "application/octet-stream")

        cache_row = HttpCache(
            url=url,
            request_hash=req_hash,
            status_code=int(resp.status_code),
            headers_json=dict(resp.headers),
            content_type=str(content_type)[:128],
            body_bytes=resp.content,
            fetched_at=now,
            expires_at=now + timedelta(seconds=int(ttl_seconds)),
        )
        try:
            self.session.add(cache_row)
            self.session.commit()
        except Exception as e:
            self.session.rollback()
            log.warning("http_cache_write_failed", extra={"url": url, "error": str(e)})

        return CachedResponse(
            url=str(resp.url),
            status_code=int(resp.status_code),
            headers=dict(resp.headers),
            content=resp.content,
            content_type=str(content_type),
        )
