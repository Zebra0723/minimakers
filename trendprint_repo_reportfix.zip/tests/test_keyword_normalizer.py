from app.keywords.normalizer import KeywordNormalizer, normalize_text, is_hard_banned


def test_normalize_text_basic():
    assert normalize_text("  Hello, World!  ") == "hello world"
    assert normalize_text("Key-chain & charms") == "key-chain and charms"


def test_keyword_expansion():
    kn = KeywordNormalizer()
    out = kn.normalize_keywords(["Keychain", "Fidget"])
    kw = {o.normalized_keyword: o for o in out}
    assert "keychain" in kw
    assert "keyring" in kw["keychain"].expansions
    assert "fidget" in kw
    assert any("fidget toy" == e for e in kw["fidget"].expansions)


def test_hard_ban_keywords():
    assert is_hard_banned("gun") is True
    kn = KeywordNormalizer()
    out = kn.normalize_keywords(["Gun", "Cute cat"])
    assert out[0].rejected_reason == "hard_banned_keyword"
    assert out[1].rejected_reason is None
