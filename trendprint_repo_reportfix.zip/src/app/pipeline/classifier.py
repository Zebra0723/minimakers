from __future__ import annotations

import re

from app.schemas import Classification


_CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "fidget": [
        "fidget",
        "spinner",
        "click",
        "clicky",
        "clicker",
        "ratchet",
        "slider",
        "haptic",
        "tactile",
        "dial",
        "roller",
        "worry coin",
        "worry",
        "stress",
        "pop",
        "snap",
        "gear",
        "spinning",
        "print in place",
        "print-in-place",
    ],
    "figurine": [
        "figurine",
        "figure",
        "mini figure",
        "miniature",
        "mini",
        "chibi",
        "character",
        "mascot",
        "cute",
        "animal",
        "cat",
        "dog",
        "bear",
        "dino",
        "dragon",
    ],
    "mini-toy": [
        "toy",
        "desk buddy",
        "desk toy",
        "desk pet",
        "desk friend",
        "mini toy",
        "articulated",
        "flexi",
        "flexible",
        "hinge",
        "snap fit",
        "snap-fit",
        "kit card",
        "kit-card",
        "puzzle",
        "keychain",
        "keyring",
        "charm",
    ],
    "utility": [
        "holder",
        "mount",
        "bracket",
        "adapter",
        "case",
        "stand",
        "tool",
        "replacement",
        "spare part",
        "functional",
        "organizer",
        "storage",
        "drawer",
        "bin",
    ],
}


# Hard signals used to prevent misclassification of obvious non-blind-box items.
_HARD_UTILITY_TERMS = {
    "wall mount",
    "mount",
    "bracket",
    "adapter",
    "holder",
    "stand",
    "replacement",
    "spare part",
    "tool",
    "organizer",
    "storage",
    "battery",
    "case",
    "enclosure",
    "rack",
}

_HARD_DECOR_TERMS = {
    "vase",
    "planter",
    "lithophane",
    "lamp",
    "lampshade",
    "shade",
    "wall art",
    "wallart",
    "sign",
    "plaque",
    "coaster",
    "christmas tree",
    "tree topper",
    "wreath",
}


def classify_model(title: str, description: str, tags: list[str]) -> Classification:
    text = " ".join([title or "", description or "", " ".join(tags or [])]).lower()

    # Token set for safer keyword checks (avoid substrings like "mount" in "mountain").
    tokens = set(re.findall(r"[a-z0-9]+", text))

    # Early exits: avoid classifying obvious tools/decor as toys.
    def _term_present(term: str) -> bool:
        return term in text if " " in term else term in tokens

    if any(_term_present(t) for t in _HARD_UTILITY_TERMS):
        return Classification(type="utility", confidence=0.9)
    if any(_term_present(t) for t in _HARD_DECOR_TERMS):
        # Decor isn't automatically disallowed, but it's rarely blind-box friendly.
        return Classification(type="other", confidence=0.75)

    scores: dict[str, float] = {}
    for cat, words in _CATEGORY_KEYWORDS.items():
        s = 0.0
        for w in words:
            if w in text:
                # Longer phrases count slightly more
                s += 1.5 if " " in w else 1.0
        scores[cat] = s

    # Default bucket
    best_cat = "other"
    best_score = 0.0
    second_best = 0.0
    for cat, s in scores.items():
        if s > best_score:
            second_best = best_score
            best_score = s
            best_cat = cat
        elif s > second_best:
            second_best = s

    if best_score <= 0:
        return Classification(type="other", confidence=0.2)

    # Confidence: how clearly the winner beats the runner-up
    gap = best_score - second_best
    confidence = min(1.0, 0.45 + 0.15 * gap)
    return Classification(type=best_cat, confidence=confidence)
