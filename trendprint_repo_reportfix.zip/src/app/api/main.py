from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import FastAPI
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
from sqlalchemy import select, desc

from app.config import get_settings
from app.db.session import make_session_factory
from app.db.models import Run, Recommendation

settings = get_settings()
SessionFactory = make_session_factory(settings)

app = FastAPI(title="TrendPrint", version="0.1.0")

REQ_COUNTER = Counter("trendprint_http_requests_total", "HTTP requests", ["path"])
REQ_LATENCY = Histogram("trendprint_http_request_latency_seconds", "HTTP request latency", ["path"])


@app.get("/health")
def health() -> dict[str, Any]:
    with SessionFactory() as session:
        # Simple DB ping
        session.execute(select(1))
    return {"status": "ok", "time_utc": datetime.utcnow().isoformat() + "Z"}


@app.get("/recommendations/latest")
def latest_recommendations(limit: int = 25) -> dict[str, Any]:
    with SessionFactory() as session:
        run = session.execute(select(Run).order_by(desc(Run.started_at)).limit(1)).scalar_one_or_none()
        if not run:
            return {"run_id": None, "items": []}
        recs = session.execute(
            select(Recommendation).where(Recommendation.run_id == run.id).order_by(Recommendation.rank).limit(limit)
        ).scalars().all()
        return {"run_id": run.id, "items": [r.report_json for r in recs]}


@app.get("/metrics")
def metrics() -> Response:
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)
