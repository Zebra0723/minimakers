from __future__ import annotations

import time
from pathlib import Path

import typer

from app.config import get_settings
from app.db.session import make_session_factory
from app.logging_utils import configure_logging, get_logger
from app.notifier.report import write_reports
from app.notifier.webhook import notify_webhooks
from app.pipeline.orchestrator import PipelineRunner

log = get_logger(__name__)


def main(
    region: str = typer.Option(None, "--region", help="Market/region (default from env)."),
    limit: int = typer.Option(25, "--limit", help="Number of shortlisted items to output."),
    output: Path = typer.Option(Path("reports"), "--output", help="Output directory for reports."),
    every_minutes: int = typer.Option(240, "--every-minutes", help="Run interval in minutes."),
):
    settings = get_settings()
    configure_logging(settings.log_level)

    region_final = region or settings.default_region
    output_dir = output

    SessionFactory = make_session_factory(settings)
    runner = PipelineRunner(settings)

    log.info("scheduler_started", extra={"region": region_final, "every_minutes": every_minutes})

    while True:
        try:
            # Keep session open while writing the report so it can include
            # real trend/keyword/search context.
            with SessionFactory() as session:
                run_id, items = runner.run_once(session, region=region_final, limit=limit, output_dir=output_dir)
                paths = write_reports(items, output_dir, region=region_final, run_id=run_id, session=session)
            notify_webhooks(
                items,
                region=region_final,
                slack_url=str(settings.slack_webhook_url) if settings.slack_webhook_url else None,
                discord_url=str(settings.discord_webhook_url) if settings.discord_webhook_url else None,
            )
            log.info(
                "scheduled_run_complete",
                extra={"run_id": run_id, "shortlisted": len(items), "json_report": str(paths["json"])},
            )
        except Exception as e:
            log.exception("scheduled_run_failed", extra={"error": str(e)})

        time.sleep(max(60, int(every_minutes) * 60))


if __name__ == "__main__":
    typer.run(main)
