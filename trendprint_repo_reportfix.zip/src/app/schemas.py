from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, ConfigDict


class TrendInfo(BaseModel):
    region: str
    source: str = "google_trends"
    momentum_score: float = 0.0
    evidence: list[str] = Field(default_factory=list)


class ModelStats(BaseModel):
    likes: int = 0
    downloads: int = 0
    makes: int = 0


class MakerWorldModel(BaseModel):
    # Avoid pydantic's protected namespace warning for "model_id"
    model_config = ConfigDict(protected_namespaces=())

    title: str
    makerworld_url: str
    creator: str = ""
    license: str = ""
    tags: list[str] = Field(default_factory=list)
    stats: ModelStats = Field(default_factory=ModelStats)
    description: str = ""
    model_id: str | None = None
    published_at: datetime | None = None


class Classification(BaseModel):
    type: Literal["fidget", "figurine", "mini-toy", "utility", "other"]
    confidence: float = 0.0


class PrintEstimate(BaseModel):
    max_dimension_mm: int = 0
    grams_est: float = 0.0
    time_minutes_est: int = 0
    supports_likely: bool = False

    # Blind-box optimisations (heuristic, best-effort)
    # These are intentionally stored inside JSON outputs so we can iterate without
    # DB migrations.
    parts_est: int = 1
    scaled_down: bool = False
    scale_factor: float = 1.0
    requires_hardware: bool = False
    fragility_risk: float = 0.0


class ScoreBreakdown(BaseModel):
    total: float = 0.0
    trend: float = 0.0
    relevance: float = 0.0
    # Extra transparency signal: how confident we are that the *trend keyword* maps
    # to a physical, sellable model (0..100). This feeds into relevance scoring.
    trend_relevance_confidence: float = 0.0
    popularity: float = 0.0
    freshness: float = 0.0
    printability: float = 0.0
    blind_box_fit: float = 0.0


class RecommendationItem(BaseModel):
    keyword: str
    trend: TrendInfo
    model: MakerWorldModel
    classification: Classification
    print_estimate: PrintEstimate
    scores: ScoreBreakdown
    verdict: Literal["DO", "MAYBE", "SKIP"]
    notes: list[str] = Field(default_factory=list)

    # Internal flags (still included in JSON for auditability)
    manual_review_required: bool = False
    rejected_reasons: list[str] = Field(default_factory=list)
    uncertainty: str | None = None
