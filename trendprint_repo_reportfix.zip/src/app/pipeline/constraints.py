from __future__ import annotations

from dataclasses import dataclass

from app.config import Settings
from app.schemas import PrintEstimate


@dataclass(frozen=True)
class ConstraintResult:
    passed: bool
    reasons: list[str]


def check_blind_box_constraints(
    est: PrintEstimate,
    *,
    settings: Settings,
    supports_ok: bool = True,
    content_ok: bool = True,
    license_ok: bool = True,
    durability_ok: bool = True,
    scaling_ok: bool = True,
) -> ConstraintResult:
    reasons: list[str] = []

    if not content_ok:
        reasons.append("content_not_allowed")
    if not license_ok:
        reasons.append("license_not_allowed")

    # Size
    if est.max_dimension_mm > settings.max_dimension_mm:
        reasons.append(f"too_large:{est.max_dimension_mm}mm")
    # Time
    if est.time_minutes_est > settings.max_print_time_minutes:
        reasons.append(f"too_slow:{est.time_minutes_est}min")
    # Material
    if est.grams_est > settings.max_filament_grams:
        reasons.append(f"too_much_filament:{est.grams_est}g")
    # Supports
    if not supports_ok:
        reasons.append("supports_likely")

    # Assembly / hardware
    # Blind-box ops favour single-part prints with no extra components.
    if getattr(est, "requires_hardware", False):
        reasons.append("requires_external_hardware")
    parts_est = int(getattr(est, "parts_est", 1) or 1)
    if parts_est > int(settings.max_parts):
        reasons.append(f"too_many_parts:{parts_est}")
    # Durability
    if not durability_ok:
        reasons.append("fragile_geometry")
    # Scaling
    if not scaling_ok:
        reasons.append("scaling_uncertain")

    return ConstraintResult(passed=(len(reasons) == 0), reasons=reasons)
