from __future__ import annotations

from pydantic import AnyHttpUrl, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    '''
    Configuration via environment variables.

    NOTE:
    - Do not store secrets in code.
    - Provide defaults that are conservative (no scraping by default).
    '''

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Database
    database_url: str = Field(default="sqlite:///./trendprint.db", alias="DATABASE_URL")

    # Region / Trends
    default_region: str = Field(default="UK", alias="DEFAULT_REGION")
    google_trends_geo: str = Field(default="GB", alias="GOOGLE_TRENDS_GEO")
    google_trends_hl: str = Field(default="en-GB", alias="GOOGLE_TRENDS_HL")
    google_trends_tz: int = Field(default=0, alias="GOOGLE_TRENDS_TZ")
    trends_timeframe: str = Field(default="now 7-d", alias="TRENDS_TIMEFRAME")
    trends_top_k: int = Field(default=50, alias="TRENDS_TOP_K")
    related_queries_top_k: int = Field(default=10, alias="RELATED_QUERIES_TOP_K")

    # MakerWorld adapter
    makerworld_adapter: str = Field(default="dataset", alias="MAKERWORLD_ADAPTER")  # dataset|web
    makerworld_base_url: str = Field(default="https://makerworld.com", alias="MAKERWORLD_BASE_URL")
    makerworld_requests_per_minute: int = Field(default=30, alias="MAKERWORLD_REQUESTS_PER_MINUTE")
    makerworld_http_cache_ttl_seconds: int = Field(default=21600, alias="MAKERWORLD_HTTP_CACHE_TTL_SECONDS")
    makerworld_scraping_allowed: bool = Field(default=False, alias="MAKERWORLD_SCRAPING_ALLOWED")

    # Dataset adapter
    makerworld_dataset_path: str = Field(default="data/makerworld_dataset.jsonl", alias="MAKERWORLD_DATASET_PATH")

    # Filtering thresholds
    max_dimension_mm: int = Field(default=80, alias="MAX_DIMENSION_MM")
    max_print_time_minutes: int = Field(default=90, alias="MAX_PRINT_TIME_MINUTES")
    max_filament_grams: int = Field(default=30, alias="MAX_FILAMENT_GRAMS")

    # Blind-box assembly complexity
    # We strongly prefer single-part prints. Allowing up to 2 parts keeps options
    # like simple two-piece fidgets viable while rejecting large kits.
    max_parts: int = Field(default=2, alias="MAX_PARTS")

    # Relevance gating (noise reduction)
    # These thresholds intentionally bias toward fewer, higher-quality matches.
    min_relevance_score: float = Field(default=55.0, alias="MIN_RELEVANCE_SCORE")
    min_trend_relevance_confidence: float = Field(
        default=45.0,
        alias="MIN_TREND_RELEVANCE_CONFIDENCE",
    )

    # Reports
    report_top_n: int = Field(default=25, alias="REPORT_TOP_N")

    # Scoring weights (must sum to 1.0)
    # Updated defaults (iteration 2): reduce over-indexing on raw trend momentum and
    # increase emphasis on relevance + printability + blind-box suitability.
    # This reduces false positives where a high-momentum trend accidentally matches
    # unrelated models.
    weight_trend: float = Field(default=0.15, alias="WEIGHT_TREND")
    weight_relevance: float = Field(default=0.25, alias="WEIGHT_RELEVANCE")
    weight_popularity: float = Field(default=0.17, alias="WEIGHT_POPULARITY")
    weight_freshness: float = Field(default=0.05, alias="WEIGHT_FRESHNESS")
    weight_printability: float = Field(default=0.23, alias="WEIGHT_PRINTABILITY")
    weight_blind_box_fit: float = Field(default=0.15, alias="WEIGHT_BLIND_BOX_FIT")

    # Optional notifications
    slack_webhook_url: AnyHttpUrl | None = Field(default=None, alias="SLACK_WEBHOOK_URL")
    discord_webhook_url: AnyHttpUrl | None = Field(default=None, alias="DISCORD_WEBHOOK_URL")

    # Logging
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # Misc
    user_agent: str = Field(
        default="TrendPrintBot/0.1 (+https://example.invalid; contact=you@example.invalid)",
        alias="USER_AGENT",
    )


def get_settings() -> Settings:
    return Settings()
