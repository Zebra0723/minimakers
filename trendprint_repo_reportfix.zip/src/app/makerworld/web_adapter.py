from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable

from bs4 import BeautifulSoup
from dateutil import parser as dateparser
from rapidfuzz import fuzz

from urllib.robotparser import RobotFileParser

from app.http_client import CachedHttpClient
from app.logging_utils import get_logger
from app.makerworld.adapter_base import MakerWorldSearchAdapter, MakerWorldSearchResult
from app.schemas import MakerWorldModel, ModelStats

log = get_logger(__name__)


_NEXT_DATA_RE = re.compile(r"__NEXT_DATA__")


def _safe_json_load(s: str) -> Any | None:
    try:
        return json.loads(s)
    except Exception:
        return None


def _iter_dicts(obj: Any) -> Iterable[dict[str, Any]]:
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            yield from _iter_dicts(v)
    elif isinstance(obj, list):
        for it in obj:
            yield from _iter_dicts(it)


def _find_next_data(html: str) -> dict[str, Any] | None:
    soup = BeautifulSoup(html, "html.parser")
    script = soup.find("script", id="__NEXT_DATA__")
    if script and script.string:
        data = _safe_json_load(script.string)
        if isinstance(data, dict):
            return data
    return None


def _find_jsonld_itemlist(html: str) -> list[dict[str, Any]]:
    soup = BeautifulSoup(html, "html.parser")
    out: list[dict[str, Any]] = []
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        if not script.string:
            continue
        data = _safe_json_load(script.string)
        if not data:
            continue
        if isinstance(data, dict) and data.get("@type") == "ItemList":
            elements = data.get("itemListElement") or []
            if isinstance(elements, list):
                for el in elements:
                    if isinstance(el, dict):
                        out.append(el)
    return out


def _slugify(title: str) -> str:
    t = title.lower()
    t = re.sub(r"[^a-z0-9]+", "-", t).strip("-")
    return t[:80]


def _extract_stats(d: dict[str, Any]) -> ModelStats:
    # Try common key names
    likes = d.get("likeCount") or d.get("likes") or d.get("like") or 0
    downloads = d.get("downloadCount") or d.get("downloads") or d.get("download") or 0
    makes = d.get("makeCount") or d.get("makes") or d.get("successfulPrints") or 0
    try:
        return ModelStats(likes=int(likes or 0), downloads=int(downloads or 0), makes=int(makes or 0))
    except Exception:
        return ModelStats()


def _extract_datetime(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return dateparser.parse(str(value))
    except Exception:
        return None


@dataclass
class _ParsedModel:
    model_id: str
    title: str
    url: str
    creator: str
    tags: list[str]
    license: str | None
    stats: ModelStats
    published_at: datetime | None
    raw: dict[str, Any]


class MakerWorldWebAdapter(MakerWorldSearchAdapter):
    '''
    Best-effort web adapter.

    ⚠️ Only enable if you have verified MakerWorld access is permitted.
    - Set MAKERWORLD_SCRAPING_ALLOWED=true
    - Keep low request rates
    - Use caching (http_cache table)

    Implementation notes:
    - MakerWorld pages are likely dynamic (e.g. Next.js). We try to parse `__NEXT_DATA__`.
    - If parsing fails, results may be incomplete and will be filtered out by strict license rules.
    '''

    def __init__(self, http: CachedHttpClient, base_url: str, ttl_seconds: int, scraping_allowed: bool, user_agent: str):
        self.http = http
        self.base_url = base_url.rstrip("/")
        self.ttl_seconds = ttl_seconds
        self.scraping_allowed = scraping_allowed
        self.user_agent = user_agent
        self._robots: RobotFileParser | None = None

    def _load_robots(self) -> RobotFileParser:
        if self._robots is not None:
            return self._robots

        robots_url = f"{self.base_url}/robots.txt"
        resp = self.http.get(robots_url, ttl_seconds=86400)
        if resp.status_code >= 400:
            raise PermissionError(f"robots.txt fetch failed: status={resp.status_code}")

        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.parse(resp.text.splitlines())

        self._robots = rp
        return rp

    def _robots_allows(self, url: str) -> bool:
        rp = self._load_robots()
        # If parsing failed for any reason, be conservative.
        try:
            return bool(rp.can_fetch(self.user_agent or "*", url))
        except Exception:
            return False

    def _guard(self) -> None:
        if not self.scraping_allowed:
            raise PermissionError(
                "MakerWorld web adapter is disabled. Set MAKERWORLD_SCRAPING_ALLOWED=true after verifying permission."
            )

        # Respect robots.txt (best-effort but conservative).
        try:
            test_urls = [
                f"{self.base_url}/search",
                f"{self.base_url}/models/search",
                f"{self.base_url}/en/models/1",
            ]
            for u in test_urls:
                if not self._robots_allows(u):
                    raise PermissionError(f"robots_disallow:{u}")
        except PermissionError:
            raise
        except Exception as e:
            raise PermissionError(f"robots_check_failed:{e}") from e

    def _search_urls(self, keyword: str) -> list[tuple[str, dict[str, Any]]]:
        # Try multiple known-ish patterns.
        q = keyword
        return [
            (f"{self.base_url}/models/search", {"keyword": q}),
            (f"{self.base_url}/en/search", {"keyword": q}),
            (f"{self.base_url}/search", {"keyword": q}),
        ]

    def search(self, keyword: str, limit: int = 20) -> list[MakerWorldSearchResult]:
        self._guard()

        last_error: str | None = None
        html: str | None = None
        used_url: str | None = None

        for url, params in self._search_urls(keyword):
            try:
                resp = self.http.get(url, params=params, ttl_seconds=self.ttl_seconds)
                used_url = resp.url
                if resp.status_code >= 400:
                    last_error = f"{resp.status_code} from {url}"
                    continue
                html = resp.text
                if html and "__NEXT_DATA__" in html:
                    break
            except Exception as e:
                last_error = str(e)
                continue

        if not html:
            log.warning("makerworld_search_failed", extra={"keyword": keyword, "error": last_error or "no_html"})
            return []

        parsed = self._parse_search_page(html)
        # Rank by keyword relevance (title + tags)
        scored: list[tuple[float, _ParsedModel]] = []
        for m in parsed:
            hay = " ".join([m.title, " ".join(m.tags)]).lower()
            score = float(fuzz.token_set_ratio(keyword.lower(), hay))
            scored.append((score, m))
        scored.sort(key=lambda x: x[0], reverse=True)

        results: list[MakerWorldSearchResult] = []
        for score, m in scored[:limit]:
            results.append(
                MakerWorldSearchResult(
                    model_id=m.model_id,
                    title=m.title,
                    makerworld_url=m.url,
                    creator=m.creator,
                    tags=m.tags,
                    license=m.license,
                    stats=m.stats,
                    published_at=m.published_at,
                    raw={**m.raw, "_web_relevance": score, "_search_url": used_url},
                )
            )
        return results

    def _parse_search_page(self, html: str) -> list[_ParsedModel]:
        out: list[_ParsedModel] = []

        next_data = _find_next_data(html)
        if next_data:
            # Heuristic: scan all dicts and pick those that look like model cards.
            for d in _iter_dicts(next_data):
                model_id = d.get("modelId") or d.get("id")
                title = d.get("title") or d.get("name")
                if not model_id or not title:
                    continue
                model_id = str(model_id)
                title = str(title).strip()
                if not title:
                    continue

                creator = str(d.get("creatorName") or d.get("author") or d.get("userName") or d.get("creator") or "")
                tags = d.get("tags") or d.get("tagList") or []
                if isinstance(tags, str):
                    tags = [tags]
                if not isinstance(tags, list):
                    tags = []
                tags = [str(t) for t in tags if str(t).strip()]

                license_ = d.get("license") or d.get("licenseName") or d.get("licenseType")
                if license_:
                    license_ = str(license_)

                stats = _extract_stats(d)
                published_at = _extract_datetime(d.get("publishTime") or d.get("publishedAt") or d.get("createTime"))

                # URL
                url = d.get("url") or d.get("link") or ""
                if url and isinstance(url, str) and url.startswith("/"):
                    url = self.base_url + url
                if not url:
                    slug = _slugify(title)
                    url = f"{self.base_url}/en/models/{model_id}-{slug}"

                out.append(
                    _ParsedModel(
                        model_id=model_id,
                        title=title,
                        url=url,
                        creator=creator,
                        tags=tags,
                        license=license_,
                        stats=stats,
                        published_at=published_at,
                        raw=d,
                    )
                )

        # Fallback: JSON-LD ItemList
        if not out:
            for el in _find_jsonld_itemlist(html):
                item = el.get("item") or {}
                if not isinstance(item, dict):
                    continue
                url = item.get("@id") or item.get("url") or ""
                name = item.get("name") or ""
                if not url or not name:
                    continue
                # Try to extract model_id from URL
                m = re.search(r"/models/(\d+)", str(url))
                model_id = m.group(1) if m else _slugify(str(url))
                out.append(
                    _ParsedModel(
                        model_id=str(model_id),
                        title=str(name),
                        url=str(url),
                        creator="",
                        tags=[],
                        license=None,
                        stats=ModelStats(),
                        published_at=None,
                        raw={"jsonld": el},
                    )
                )

        # Deduplicate by model_id
        seen = set()
        deduped: list[_ParsedModel] = []
        for m in out:
            if m.model_id in seen:
                continue
            seen.add(m.model_id)
            deduped.append(m)
        return deduped

    def fetch_details(self, result: MakerWorldSearchResult) -> MakerWorldModel:
        self._guard()

        url = result.makerworld_url
        resp = self.http.get(url, ttl_seconds=self.ttl_seconds)
        if resp.status_code >= 400:
            # Return minimal info; pipeline will likely reject due to missing license, etc.
            return MakerWorldModel(
                title=result.title,
                makerworld_url=url,
                creator=result.creator or "",
                license=result.license or "",
                tags=result.tags or [],
                stats=result.stats or ModelStats(),
                description="",
                model_id=result.model_id,
                published_at=result.published_at,
            )

        html = resp.text
        next_data = _find_next_data(html)

        title = result.title
        creator = result.creator or ""
        tags = result.tags or []
        license_ = result.license or ""
        stats = result.stats or ModelStats()
        description = ""

        published_at = result.published_at

        if next_data:
            # Similar heuristic: find dict with matching id that includes richer fields.
            best: dict[str, Any] | None = None
            for d in _iter_dicts(next_data):
                model_id = d.get("modelId") or d.get("id")
                if not model_id:
                    continue
                if str(model_id) != str(result.model_id):
                    continue
                # Prefer dicts with description/license/tags
                if any(k in d for k in ("description", "license", "licenseName", "tags", "tagList")):
                    best = d
                    break

            if best:
                title = str(best.get("title") or best.get("name") or title)
                creator = str(best.get("creatorName") or best.get("author") or best.get("userName") or creator)
                description = str(best.get("description") or best.get("desc") or "")
                tags_obj = best.get("tags") or best.get("tagList") or tags
                if isinstance(tags_obj, str):
                    tags_obj = [tags_obj]
                if isinstance(tags_obj, list):
                    tags = [str(t) for t in tags_obj if str(t).strip()]
                lic = best.get("license") or best.get("licenseName") or best.get("licenseType")
                if lic:
                    license_ = str(lic)
                stats = _extract_stats(best) or stats
                published_at = _extract_datetime(best.get("publishTime") or best.get("publishedAt") or best.get("createTime")) or published_at

        return MakerWorldModel(
            title=title,
            makerworld_url=url,
            creator=creator,
            license=license_,
            tags=tags,
            stats=stats,
            description=description,
            model_id=result.model_id,
            published_at=published_at,
        )
