from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    DateTime,
    Float,
    Integer,
    LargeBinary,
    String,
    Text,
    UniqueConstraint,
    Index,
    ForeignKey,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base


def _uuid() -> str:
    return str(uuid.uuid4())


class Run(Base):
    __tablename__ = "runs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    region: Mapped[str] = mapped_column(String(16), nullable=False, index=True)

    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    status: Mapped[str] = mapped_column(String(16), default="running", nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    trend_snapshots: Mapped[list["TrendSnapshot"]] = relationship(back_populates="run", cascade="all, delete-orphan")
    keywords: Mapped[list["Keyword"]] = relationship(back_populates="run", cascade="all, delete-orphan")
    makerworld_results: Mapped[list["MakerWorldResult"]] = relationship(back_populates="run", cascade="all, delete-orphan")
    model_scores: Mapped[list["ModelScore"]] = relationship(back_populates="run", cascade="all, delete-orphan")
    recommendations: Mapped[list["Recommendation"]] = relationship(back_populates="run", cascade="all, delete-orphan")


class TrendSnapshot(Base):
    __tablename__ = "trend_snapshots"
    __table_args__ = (UniqueConstraint("run_id", "keyword", name="uq_trend_run_keyword"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(String(36), ForeignKey("runs.id", ondelete="CASCADE"), nullable=False, index=True)

    region: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    keyword: Mapped[str] = mapped_column(String(256), nullable=False)

    source: Mapped[str] = mapped_column(String(64), default="google_trends", nullable=False)
    momentum_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    evidence_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    raw_json: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    run: Mapped["Run"] = relationship(back_populates="trend_snapshots")


class Keyword(Base):
    __tablename__ = "keywords"
    __table_args__ = (UniqueConstraint("run_id", "normalized_keyword", name="uq_keyword_run_norm"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(String(36), ForeignKey("runs.id", ondelete="CASCADE"), nullable=False, index=True)

    source_keyword: Mapped[str] = mapped_column(String(256), nullable=False)
    normalized_keyword: Mapped[str] = mapped_column(String(256), nullable=False, index=True)
    expansions_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    run: Mapped["Run"] = relationship(back_populates="keywords")


class MakerWorldResult(Base):
    __tablename__ = "makerworld_results"
    __table_args__ = (
        UniqueConstraint("run_id", "keyword", "model_id", name="uq_mw_run_keyword_model"),
        Index("ix_mw_run_model", "run_id", "model_id"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(String(36), ForeignKey("runs.id", ondelete="CASCADE"), nullable=False, index=True)

    keyword: Mapped[str] = mapped_column(String(256), nullable=False, index=True)

    model_id: Mapped[str] = mapped_column(String(64), nullable=False)
    makerworld_url: Mapped[str] = mapped_column(String(512), nullable=False)

    title: Mapped[str] = mapped_column(String(512), nullable=False, default="")
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    creator: Mapped[str] = mapped_column(String(256), nullable=False, default="")
    license: Mapped[str] = mapped_column(String(256), nullable=False, default="")

    tags_json: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    stats_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)

    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    raw_json: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    run: Mapped["Run"] = relationship(back_populates="makerworld_results")


class ModelScore(Base):
    __tablename__ = "model_scores"
    __table_args__ = (UniqueConstraint("run_id", "keyword", "model_id", name="uq_score_run_keyword_model"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(String(36), ForeignKey("runs.id", ondelete="CASCADE"), nullable=False, index=True)

    keyword: Mapped[str] = mapped_column(String(256), nullable=False, index=True)
    model_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)

    total_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    verdict: Mapped[str] = mapped_column(String(16), nullable=False, default="SKIP")

    scores_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    notes_json: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    run: Mapped["Run"] = relationship(back_populates="model_scores")


class Recommendation(Base):
    __tablename__ = "recommendations"
    __table_args__ = (
        UniqueConstraint("run_id", "rank", name="uq_rec_run_rank"),
        Index("ix_rec_run_rank", "run_id", "rank"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    run_id: Mapped[str] = mapped_column(String(36), ForeignKey("runs.id", ondelete="CASCADE"), nullable=False, index=True)

    rank: Mapped[int] = mapped_column(Integer, nullable=False)

    keyword: Mapped[str] = mapped_column(String(256), nullable=False)
    model_id: Mapped[str] = mapped_column(String(64), nullable=False)

    report_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)

    run: Mapped["Run"] = relationship(back_populates="recommendations")


class HttpCache(Base):
    __tablename__ = "http_cache"
    __table_args__ = (
        UniqueConstraint("url", "request_hash", name="uq_cache_url_hash"),
        Index("ix_cache_expires", "expires_at"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)

    url: Mapped[str] = mapped_column(String(1024), nullable=False)
    request_hash: Mapped[str] = mapped_column(String(64), nullable=False)

    status_code: Mapped[int] = mapped_column(Integer, nullable=False)
    headers_json: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False, default=dict)
    content_type: Mapped[str] = mapped_column(String(128), nullable=False, default="application/octet-stream")

    body_bytes: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)

    fetched_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.utcnow, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
