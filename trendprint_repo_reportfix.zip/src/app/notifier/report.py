from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from collections import Counter, defaultdict

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Keyword, MakerWorldResult, ModelScore, Run, TrendSnapshot
from app.keywords.normalizer import KeywordNormalizer

from app.schemas import RecommendationItem


def _ts_slug(dt: datetime | None = None) -> str:
    """Return a stable timestamp slug for report filenames.

    We generate the slug once per run so the JSON + Markdown report share the same
    timestamp (avoids mismatched filenames when a run crosses a minute boundary).
    """

    dt = dt or datetime.now(timezone.utc)
    return dt.strftime("%Y%m%d_%H%M")


def write_json_report(
    items: list[RecommendationItem],
    output_dir: Path,
    *,
    prefix: str = "recommendations",
    slug: str | None = None,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{prefix}_{slug or _ts_slug()}.json"
    payload = [it.model_dump() for it in items]
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return int(default)


def _parse_rejected_reasons(notes: list[str]) -> list[str]:
    for n in notes or []:
        if isinstance(n, str) and n.startswith("rejected_reasons:"):
            payload = n.split(":", 1)[1]
            parts = [p.strip() for p in payload.split(";") if p.strip()]
            return parts
    return []


def _top_reason_notes(item: RecommendationItem, *, max_notes: int = 4) -> list[str]:
    """Pick a small set of human-readable reasons for the shortlist.

    Notes are already structured-ish (prefix:value). We keep only the most
    business-relevant signals so the report stays readable.
    """

    preferred_prefixes = (
        "trend_breakout_signal",
        "trend_rising",
        "trend_signal",
        "trend_related_queries",
        "model_popularity",
        "print_estimate",
        "printability",
        "filament_cost_est",
        "trend_relevance_confidence",
        "license_check",
    )

    out: list[str] = []
    for n in item.notes or []:
        if not isinstance(n, str):
            continue
        if n.startswith("rejected_reasons:"):
            continue
        if n.startswith(preferred_prefixes):
            out.append(n)
        if len(out) >= max_notes:
            break
    # Fallback if we didn't match anything
    if not out:
        out = (item.notes or [])[:max_notes]
    return out


def write_markdown_report(
    items: list[RecommendationItem],
    output_dir: Path,
    *,
    region: str,
    prefix: str = "recommendations",
    slug: str | None = None,
    run_id: str | None = None,
    session: Session | None = None,
    json_report_path: Path | None = None,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{prefix}_{slug or _ts_slug()}.md"

    lines: list[str] = []
    now_dt = datetime.now(timezone.utc)
    now = now_dt.strftime("%Y-%m-%d %H:%M UTC")

    # -----------------
    # Fetch run context (best-effort)
    # -----------------
    run: Run | None = None
    trend_rows: list[TrendSnapshot] = []
    keyword_rows: list[Keyword] = []
    mw_rows: list[MakerWorldResult] = []
    score_rows: list[ModelScore] = []

    if session is not None and run_id:
        try:
            run = session.get(Run, run_id)
            trend_rows = (
                session.execute(
                    select(TrendSnapshot)
                    .where(TrendSnapshot.run_id == run_id)
                    .order_by(TrendSnapshot.momentum_score.desc(), TrendSnapshot.keyword.asc())
                )
                .scalars()
                .all()
            )
            keyword_rows = (
                session.execute(select(Keyword).where(Keyword.run_id == run_id).order_by(Keyword.normalized_keyword.asc()))
                .scalars()
                .all()
            )
            mw_rows = (
                session.execute(select(MakerWorldResult).where(MakerWorldResult.run_id == run_id).order_by(MakerWorldResult.keyword.asc()))
                .scalars()
                .all()
            )
            score_rows = (
                session.execute(select(ModelScore).where(ModelScore.run_id == run_id))
                .scalars()
                .all()
            )
        except Exception:
            # Report generation must never crash the run; fall back to whatever we have.
            run = run

    # Map source trend keyword -> momentum score. Used to order concepts and
    # MakerWorld search groups by real market signal.
    momentum_by_source: dict[str, float] = {t.keyword: float(t.momentum_score) for t in (trend_rows or [])}

    # -----------------
    # 1️⃣ Header
    # -----------------
    lines.append(f"# TrendPrint Daily Report — {region}")
    lines.append("")
    lines.append("## 1️⃣ Header")
    lines.append("")

    # Use run timestamps if available; otherwise use report time.
    started_at = getattr(run, "started_at", None)
    finished_at = getattr(run, "finished_at", None)
    status = getattr(run, "status", None) or "success"

    lines.append(f"- Date & time (UTC): **{now}**")
    lines.append(f"- Region: **{region}**")
    if run_id:
        lines.append(f"- Run ID: `{run_id}`")
    if started_at:
        lines.append(f"- Started: {started_at.strftime('%Y-%m-%d %H:%M UTC')}")
    if finished_at:
        lines.append(f"- Finished: {finished_at.strftime('%Y-%m-%d %H:%M UTC')}")
    # Keep the one-line status the user asked for.
    if status == "success":
        lines.append("- Status: ✅ Pipeline ran successfully")
    elif status == "partial":
        lines.append("- Status: ⚠️ Pipeline ran partially (some sources failed; see logs)")
    else:
        lines.append(f"- Status: ❌ Pipeline status: {status}")

    lines.append("")

    # -----------------
    # 2️⃣ UK Google Trends (Real Data)
    # -----------------
    lines.append("## 2️⃣ UK Google Trends (Real Data)")
    lines.append("")

    if not trend_rows:
        lines.append("_No trend snapshots found for this run (source failure or DB issue)._ ")
        lines.append("")
    else:
        normalizer = KeywordNormalizer()

        def _trend_allowed(q: str) -> bool:
            try:
                nk = normalizer.normalize_keywords([q])
                return bool(nk) and nk[0].rejected_reason is None
            except Exception:
                return False

        relevant_trends = [t for t in trend_rows if _trend_allowed(t.keyword)]
        filtered_out = len(trend_rows) - len(relevant_trends)

        # Top rising trends (we use momentum_score which incorporates "Breakout" signals)
        lines.append(f"Top relevant trends (filtered): **{min(20, len(relevant_trends))}** shown")
        if filtered_out:
            lines.append(f"- Filtered out (news/politics/adult/non-productizable): **{filtered_out}**")
        lines.append("")

        for t in relevant_trends[:20]:
            evidence = []
            try:
                evidence = list((t.evidence_json or {}).get("evidence") or [])
            except Exception:
                evidence = []
            ev = ", ".join(evidence[:4]) if evidence else "—"
            lines.append(f"- **{t.keyword}** — momentum **{t.momentum_score:.0f}/100** — related: {ev}")
        lines.append("")

        # Top rising related queries across trends (includes explicit Breakout)
        rising_items: list[tuple[float, str, bool, str, str]] = []
        # (score, value_str, is_breakout, query, parent_keyword)
        for t in trend_rows:
            raw = t.raw_json or {}
            rq = (raw.get("related_queries") or {}) if isinstance(raw, dict) else {}
            rising = rq.get("rising") or []
            if not isinstance(rising, list):
                continue
            for row in rising:
                if not isinstance(row, dict):
                    continue
                q = str(row.get("query") or "").strip()
                if not q:
                    continue
                if not _trend_allowed(q):
                    continue
                v = row.get("value")
                is_breakout = isinstance(v, str) and v.strip().lower() == "breakout"
                value_str = "Breakout" if is_breakout else str(v) if v is not None else ""
                score = 10000.0 if is_breakout else float(v) if isinstance(v, (int, float)) else 0.0
                rising_items.append((score, value_str, is_breakout, q, t.keyword))

        if rising_items:
            # Dedupe by query (keep best score)
            best_by_query: dict[str, tuple[float, str, bool, str]] = {}
            for score, value_str, is_breakout, q, parent in rising_items:
                prev = best_by_query.get(q)
                if prev is None or score > prev[0]:
                    best_by_query[q] = (score, value_str, is_breakout, parent)

            deduped = [(q, *best_by_query[q]) for q in best_by_query]
            # (query, score, value_str, is_breakout, parent)
            deduped.sort(key=lambda x: x[1], reverse=True)

            lines.append("Top rising related queries (cross-trend):")
            for q, score, value_str, is_breakout, parent in deduped[:15]:
                badge = "🚀 Breakout" if is_breakout else f"+{value_str}%" if value_str else "rising"
                lines.append(f"- **{q}** — {badge} (via _{parent}_)" )
            lines.append("")

            breakouts = [d for d in deduped if d[3]]
            if breakouts:
                lines.append("Breakout terms:")
                for q, score, value_str, is_breakout, parent in breakouts[:10]:
                    lines.append(f"- **{q}** (via _{parent}_)" )
                lines.append("")
        else:
            lines.append("_No rising/breakout related queries were available this run (rate limits or source gaps)._ ")
            lines.append("")

    # -----------------
    # 3️⃣ Keyword Normalization
    # -----------------
    lines.append("## 3️⃣ Keyword Normalization")
    lines.append("")
    if not keyword_rows:
        lines.append("_No keywords were stored for this run._")
        lines.append("")
    else:
        kept = []
        rejected = []
        for k in keyword_rows:
            meta = k.expansions_json or {}
            if meta.get("rejected_reason"):
                rejected.append((k, str(meta.get("rejected_reason"))))
            else:
                kept.append(k)

        lines.append(f"Candidate concepts: **{len(kept)}** (rejected: {len(rejected)})")
        lines.append("")

        # Keep the list short and actionable. Sort by trend momentum (desc).
        kept_sorted = sorted(kept, key=lambda k: momentum_by_source.get(k.source_keyword, 0.0), reverse=True)
        for k in kept_sorted[:20]:
            meta = k.expansions_json or {}
            expansions = list(meta.get("expansions") or [])
            # Show only a light expansion set (avoid noise)
            shown = [e for e in expansions if e and e != k.normalized_keyword][:4]
            extra = ""
            if meta.get("manual_review_required"):
                extra = " ⚠️ manual review"
            if shown:
                lines.append(f"- **{k.normalized_keyword}**{extra} — variants: {', '.join(shown)}")
            else:
                lines.append(f"- **{k.normalized_keyword}**{extra}")

        if len(kept_sorted) > 20:
            lines.append(f"- … plus {len(kept_sorted) - 20} more")
        lines.append("")

    # -----------------
    # 4️⃣ MakerWorld Search
    # -----------------
    lines.append("## 4️⃣ MakerWorld Search")
    lines.append("")

    if not mw_rows:
        lines.append("_No MakerWorld results were stored for this run (search failed or was disabled)._ ")
        lines.append("")
    else:
        # Index scores so we can display a lightweight verdict/score next to search hits.
        score_by_kw_model: dict[tuple[str, str], ModelScore] = {}
        for s in score_rows:
            score_by_kw_model[(s.keyword, s.model_id)] = s

        by_kw: dict[str, list[MakerWorldResult]] = defaultdict(list)
        for r in mw_rows:
            by_kw[r.keyword].append(r)

        # Sort keyword groups by their source trend momentum (desc) for a more
        # actionable report ordering.
        momentum_by_norm: dict[str, float] = {}
        for k in keyword_rows or []:
            try:
                momentum_by_norm[k.normalized_keyword] = float(momentum_by_source.get(k.source_keyword, 0.0))
            except Exception:
                momentum_by_norm[k.normalized_keyword] = 0.0

        kw_order = sorted(by_kw.keys(), key=lambda kw: momentum_by_norm.get(kw, 0.0), reverse=True)

        # Keep section readable: show the top 2 hits per keyword.
        for kw in kw_order[:20]:
            models = by_kw[kw]
            lines.append(f"### {kw}  (models found: {len(models)})")
            # Sort by a simple popularity heuristic (likes + downloads + makes)
            def _pop_score(m: MakerWorldResult) -> float:
                st = m.stats_json or {}
                likes = _safe_int(st.get("likes"), 0)
                downloads = _safe_int(st.get("downloads"), 0)
                makes = _safe_int(st.get("makes"), 0)
                return float(likes) + float(downloads) * 0.03 + float(makes) * 2.0

            models_sorted = sorted(models, key=_pop_score, reverse=True)

            for m in models_sorted[:2]:
                st = m.stats_json or {}
                likes = _safe_int(st.get("likes"), 0)
                downloads = _safe_int(st.get("downloads"), 0)
                makes = _safe_int(st.get("makes"), 0)

                lic = (m.license or "").strip() or "unknown"
                score = score_by_kw_model.get((kw, m.model_id))
                score_str = f" — score {score.total_score:.1f} ({score.verdict})" if score else ""

                lines.append(
                    f"- [{m.title}]({m.makerworld_url})"
                    + (f" by _{m.creator}_" if m.creator else "")
                    + f" — ❤️{likes} ⬇️{downloads} ✅{makes} — license: `{lic}`{score_str}"
                )

            # Hint about license gating (business-critical)
            unknown_lic = sum(1 for m in models if not (m.license or "").strip())
            if unknown_lic:
                lines.append(f"- _Note: {unknown_lic} model(s) had missing/unclear license text and will be excluded by default._")
            lines.append("")

        if len(by_kw) > 20:
            lines.append(f"_({len(by_kw) - 20} more keyword groups omitted for brevity — see JSON/DB for full details.)_")
            lines.append("")

    # -----------------
    # 5️⃣ Blind-Box Filtering (Critical)
    # -----------------
    lines.append("## 5️⃣ Blind-Box Filtering (Critical)")
    lines.append("")

    # Show hard constraints up front (business value + auditability)
    lines.append("Hard gates (blind-box fit):")
    lines.append("- ✅ Small: ≤ 80mm longest dimension (or safely scalable down)")
    lines.append("- ✅ Fast: ≤ 90 minutes print time")
    lines.append("- ✅ Low material: ≤ 30g filament")
    lines.append("- ✅ Simple: single-part or ≤ 2 parts, no extra hardware")
    lines.append("- ✅ Print-friendly: avoid heavy supports; fragile geometry penalised")
    lines.append("- ✅ License: must clearly allow selling physical prints (otherwise excluded)")
    lines.append("")

    if score_rows:
        verdict_counts = Counter([s.verdict for s in score_rows])
        unique_models = len({s.model_id for s in score_rows})

        lines.append("Filtering outcomes (this run):")
        lines.append(f"- MakerWorld evaluations (keyword×model): **{len(score_rows)}**")
        lines.append(f"- Unique models scanned: **{unique_models}**")
        lines.append(f"- Verdicts: DO **{verdict_counts.get('DO', 0)}**, MAYBE **{verdict_counts.get('MAYBE', 0)}**, SKIP **{verdict_counts.get('SKIP', 0)}**")
        lines.append("")

        # Top reject reasons from notes_json (added in orchestrator)
        reason_counts: Counter[str] = Counter()
        for s in score_rows:
            reasons = _parse_rejected_reasons(list(s.notes_json or []))
            if not reasons and s.verdict == "SKIP":
                reason_counts["low_score_or_irrelevant"] += 1
                continue
            for r in reasons:
                key = str(r).split(":", 1)[0].strip() or str(r)
                reason_counts[key] += 1

        if reason_counts:
            lines.append("Top exclusion reasons (counted across keyword×model evaluations):")
            for reason, cnt in reason_counts.most_common(8):
                lines.append(f"- {reason}: **{cnt}**")
            lines.append("")
    else:
        lines.append("_No model score rows were available to summarize filtering._")
        lines.append("")

    # -----------------
    # 6️⃣ Scoring & Ranking
    # -----------------
    lines.append("## 6️⃣ Scoring & Ranking")
    lines.append("")

    lines.append(f"Top shortlist: **{min(10, len(items))}** shown (total shortlisted: {len(items)})")
    lines.append("")

    if not items:
        lines.append("_No DO/MAYBE items met all hard constraints this run._")
        lines.append("")
    else:
        # Quick table for fast scanning
        lines.append("| Rank | Verdict | Score | Model | Type | Time | Grams | Max dim | License |")
        lines.append("|---:|:---:|---:|---|---|---:|---:|---:|---|")
        for idx, it in enumerate(items[:10], start=1):
            model_link = f"[{it.model.title}]({it.model.makerworld_url})"
            lines.append(
                "| {rank} | {verdict} | {score:.1f} | {model} | {type} | {t} | {g:.1f} | {d} | {lic} |".format(
                    rank=idx,
                    verdict=it.verdict,
                    score=it.scores.total,
                    model=model_link,
                    type=it.classification.type,
                    t=it.print_estimate.time_minutes_est,
                    g=it.print_estimate.grams_est,
                    d=it.print_estimate.max_dimension_mm,
                    lic=(it.model.license or "unknown"),
                )
            )
        lines.append("")

        # Short reasons per pick
        for idx, it in enumerate(items[:10], start=1):
            lines.append(f"### {idx}. {it.model.title}")
            lines.append("")
            lines.append(f"- Link: {it.model.makerworld_url}")
            if it.model.creator:
                lines.append(f"- Creator: {it.model.creator}")
            lines.append(f"- Matched keyword: `{it.keyword}`")
            lines.append(f"- Verdict: **{it.verdict}** — score **{it.scores.total:.1f}/100**")
            lines.append(
                f"- Print estimate: **{it.print_estimate.time_minutes_est} min**, **{it.print_estimate.grams_est:.1f} g**, **{it.print_estimate.max_dimension_mm} mm**; supports likely: **{it.print_estimate.supports_likely}**"
            )
            parts_est = getattr(it.print_estimate, "parts_est", 1)
            if parts_est and int(parts_est) != 1:
                lines.append(f"- Parts estimate: ≈{parts_est}")
            if getattr(it.print_estimate, "requires_hardware", False):
                lines.append("- ⚠️ Requires extra hardware (should usually be SKIP for blind-box ops)")
            if getattr(it.print_estimate, "fragility_risk", 0.0) >= 0.15:
                lines.append(f"- Fragility risk (heuristic): {getattr(it.print_estimate, 'fragility_risk', 0.0):.2f}")

            # Scoring transparency: concise breakdown
            lines.append(
                "- Score breakdown: "
                f"trend {it.scores.trend:.1f}, "
                f"relevance {it.scores.relevance:.1f} (conf {it.scores.trend_relevance_confidence:.0f}/100), "
                f"popularity {it.scores.popularity:.1f}, "
                f"freshness {it.scores.freshness:.1f}, "
                f"printability {it.scores.printability:.1f}, "
                f"blind_box {it.scores.blind_box_fit:.1f}"
            )

            # Keep only a small set of reasons
            why = _top_reason_notes(it, max_notes=4)
            if why:
                lines.append("- Why this is a good bet:")
                for n in why:
                    lines.append(f"  - {n}")
            if it.manual_review_required:
                lines.append("- ⚠️ Manual review required: **YES**")
            lines.append("")

    # -----------------
    # 7️⃣ Final Output
    # -----------------
    lines.append("## 7️⃣ Final Output")
    lines.append("")
    lines.append(f"- Markdown report: `{path.name}`")
    if json_report_path is not None:
        lines.append(f"- JSON export: `{json_report_path.name}`")
    lines.append("- Notes: print time/material are heuristic estimates (±30%) when slicer data is not available.")
    lines.append("- Reminder: license must explicitly allow selling physical prints; anything unclear is excluded by default.")
    lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def write_reports(
    items: list[RecommendationItem],
    output_dir: Path,
    *,
    region: str,
    run_id: str | None = None,
    session: Session | None = None,
) -> dict[str, Path]:
    # Generate a single slug so filenames line up.
    slug = _ts_slug()
    json_path = write_json_report(items, output_dir, slug=slug)
    md_path = write_markdown_report(
        items,
        output_dir,
        region=region,
        slug=slug,
        run_id=run_id,
        session=session,
        json_report_path=json_path,
    )
    return {"json": json_path, "md": md_path}
