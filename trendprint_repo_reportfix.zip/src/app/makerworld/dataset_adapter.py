from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from dateutil import parser as dateparser
from rapidfuzz import fuzz

from app.logging_utils import get_logger
from app.makerworld.adapter_base import MakerWorldSearchAdapter, MakerWorldSearchResult
from app.schemas import MakerWorldModel, ModelStats

log = get_logger(__name__)


@dataclass
class _DatasetItem:
    model_id: str
    title: str
    makerworld_url: str
    creator: str
    license: str
    tags: list[str]
    description: str
    likes: int
    downloads: int
    makes: int
    published_at: datetime | None
    raw: dict[str, Any]


class MakerWorldDatasetAdapter(MakerWorldSearchAdapter):
    '''
    Searches a local JSONL dataset (one JSON object per line).

    This is the default adapter because it avoids scraping concerns.

    Expected JSONL schema per line (minimum):
    {
      "model_id": "931536",
      "title": "...",
      "makerworld_url": "https://makerworld.com/en/models/931536-scooter-bot",
      "creator": "...",
      "license": "CC BY",
      "tags": ["fidget", "toy"],
      "description": "...",
      "stats": {"likes": 10, "downloads": 200, "makes": 3},
      "published_at": "2025-10-01T12:34:56Z"
    }
    '''

    def __init__(self, dataset_path: str):
        self.dataset_path = Path(dataset_path)
        self._items: list[_DatasetItem] = []
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        self._loaded = True

        if not self.dataset_path.exists():
            log.warning("makerworld_dataset_missing", extra={"path": str(self.dataset_path)})
            self._items = []
            return

        items: list[_DatasetItem] = []
        with self.dataset_path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    model_id = str(obj.get("model_id") or obj.get("id") or "").strip()
                    if not model_id:
                        continue
                    title = str(obj.get("title") or "").strip()
                    url = str(obj.get("makerworld_url") or obj.get("url") or "").strip()
                    creator = str(obj.get("creator") or obj.get("author") or "").strip()
                    license_ = str(obj.get("license") or "").strip()
                    tags = obj.get("tags") or []
                    if not isinstance(tags, list):
                        tags = []
                    description = str(obj.get("description") or "").strip()
                    stats_obj = obj.get("stats") or {}
                    likes = int(stats_obj.get("likes") or 0)
                    downloads = int(stats_obj.get("downloads") or 0)
                    makes = int(stats_obj.get("makes") or 0)
                    published_at = obj.get("published_at") or obj.get("publishedAt")
                    dt = None
                    if published_at:
                        try:
                            dt = dateparser.parse(str(published_at))
                        except Exception:
                            dt = None

                    items.append(
                        _DatasetItem(
                            model_id=model_id,
                            title=title,
                            makerworld_url=url,
                            creator=creator,
                            license=license_,
                            tags=[str(t) for t in tags if str(t).strip()],
                            description=description,
                            likes=likes,
                            downloads=downloads,
                            makes=makes,
                            published_at=dt,
                            raw=obj,
                        )
                    )
                except Exception:
                    continue

        self._items = items
        log.info("makerworld_dataset_loaded", extra={"count": len(self._items), "path": str(self.dataset_path)})

    def search(self, keyword: str, limit: int = 20) -> list[MakerWorldSearchResult]:
        self._load()
        if not self._items:
            return []

        kw = keyword.lower().strip()
        scored: list[tuple[float, _DatasetItem]] = []
        for it in self._items:
            hay = " ".join([it.title, it.description, " ".join(it.tags)]).lower()
            if kw not in hay and fuzz.partial_ratio(kw, hay) < 65:
                continue
            # Combine partial match and token overlap
            score = float(fuzz.token_set_ratio(kw, it.title.lower()))
            score = max(score, float(fuzz.partial_ratio(kw, hay)))
            scored.append((score, it))

        scored.sort(key=lambda x: x[0], reverse=True)
        results: list[MakerWorldSearchResult] = []
        for score, it in scored[:limit]:
            results.append(
                MakerWorldSearchResult(
                    model_id=it.model_id,
                    title=it.title,
                    makerworld_url=it.makerworld_url,
                    creator=it.creator,
                    tags=it.tags,
                    license=it.license,
                    stats=ModelStats(likes=it.likes, downloads=it.downloads, makes=it.makes),
                    published_at=it.published_at,
                    raw={**it.raw, "_dataset_relevance": score},
                )
            )
        return results

    def fetch_details(self, result: MakerWorldSearchResult) -> MakerWorldModel:
        # Dataset already contains full-ish data; pass through.
        tags = result.tags or []
        stats = result.stats or ModelStats()
        return MakerWorldModel(
            title=result.title,
            makerworld_url=result.makerworld_url,
            creator=result.creator or "",
            license=result.license or "",
            tags=tags,
            stats=stats,
            description=(result.raw or {}).get("description", "") if result.raw else "",
            model_id=result.model_id,
            published_at=result.published_at,
        )
