from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from app.schemas import MakerWorldModel, PrintEstimate

_MM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*mm", re.IGNORECASE)
_DIM_RE = re.compile(r"(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)\s*mm", re.IGNORECASE)

# PLA density ~1.24 g/cm^3 (rough)
_PLA_DENSITY = 1.24

# Fill ratios (very approximate) relative to a cube sized max_dimension^3
_FILL_RATIO_BY_CLASS = {
    "fidget": 0.040,
    "mini-toy": 0.035,
    "figurine": 0.030,
    "utility": 0.050,
    "other": 0.035,
}

# Time model: tuned so 30g ≈ 90 min on a "fast common" printer (Bambu/Prusa class)
_TIME_OVERHEAD_MIN = 15
_MIN_PER_GRAM = 2.5  # minutes per gram

_DETAIL_TERMS = ["detail", "detailed", "texture", "engrave", "emboss", "deboss", "text"]

# Parts/assembly heuristics
_PARTS_RE = re.compile(r"\b(\d{1,2})\s*(?:parts?|pieces?|pcs)\b", re.IGNORECASE)
_MULTIPART_RE = re.compile(r"\b(multi\s*part|multi-part|multipart)\b", re.IGNORECASE)

# Hardware hints (blind-box unfriendly for kids and cost/ops)
_HARDWARE_TERMS = {
    "magnet",
    "magnets",
    "bearing",
    "bearings",
    "screw",
    "screws",
    "bolt",
    "bolts",
    "nut",
    "nuts",
    "spring",
    "springs",
    "heat set",
    "heat-set",
    "insert",
    "inserts",
    "glue",
    "superglue",
    "super glue",
    "ca glue",
    "cyanoacrylate",
    "m3",
    "m4",
    "m5",
    "608",
}


@dataclass(frozen=True)
class PrintabilityResult:
    estimate: PrintEstimate
    notes: list[str]
    manual_review_required: bool
    durability_ok: bool
    scaling_used: bool
    scaling_ok: bool


def _infer_dimension_mm_from_text(text: str) -> int | None:
    if not text:
        return None
    # Prefer explicit LxWxH patterns
    m = _DIM_RE.search(text)
    if m:
        dims = [float(m.group(1)), float(m.group(2)), float(m.group(3))]
        return int(round(max(dims)))

    # Otherwise, take the largest mm number mentioned (bounded)
    vals = []
    for m2 in _MM_RE.finditer(text):
        try:
            v = float(m2.group(1))
            if 1 <= v <= 500:
                vals.append(v)
        except Exception:
            continue
    if vals:
        return int(round(max(vals)))
    return None


def _supports_signals(model: MakerWorldModel, cls_type: str) -> tuple[bool, bool, list[str]]:
    """Return (supports_required, supports_uncertain, notes).

    We intentionally avoid the previous "figurines => supports" default because it
    suppressed many small figurines/desk toys that *can* print supportless.

    - supports_required=True => should be treated as near-hard reject (we don't want
      heavy supports for blind boxes).
    - supports_uncertain=True => allow but penalize + flag for manual review.
    """

    text = " ".join([model.title, model.description, " ".join(model.tags or [])]).lower()
    notes: list[str] = []

    supportless_phrases = [
        "supportless",
        "support-less",
        "support free",
        "support-free",
        "no support",
        "no supports",
        "without supports",
    ]
    if any(p in text for p in supportless_phrases) or "print in place" in text or "print-in-place" in text:
        notes.append("supports_claim:supportless")
        return False, False, notes

    required_phrases = [
        "supports required",
        "support required",
        "requires supports",
        "requires support",
        "needs supports",
        "needs support",
    ]
    if any(p in text for p in required_phrases):
        notes.append("supports_claim:required")
        return True, True, notes

    # If the description mentions supports but doesn't explicitly say required,
    # treat as uncertain (common: "supports optional", "supports only for..." etc.).
    if "support" in text:
        notes.append("supports_claim:mentioned")
        return False, True, notes

    # Category-based uncertainty: figurines and articulated toys often have overhangs,
    # but we do not want to auto-reject them.
    if cls_type in {"figurine", "mini-toy"}:
        notes.append("supports_claim:unknown")
        return False, True, notes

    return False, False, notes


def _fragility_penalty(model: MakerWorldModel) -> tuple[float, bool, list[str]]:
    """Return a fragility risk in 0..1.

    We overweight the most problematic hints ("fragile", "thin", etc.) because the
    blind-box audience (10–11) tends to be hard on small prints.
    """

    text = " ".join([model.title, model.description, " ".join(model.tags or [])]).lower()
    penalty = 0.0
    notes: list[str] = []
    manual = False

    # NOTE: We avoid treating "tiny" as fragility by default because "tiny" is often
    # a positive blind-box signal. We keep the list focused on break-prone geometry.
    weighted_terms: list[tuple[str, float]] = [
        ("fragile", 0.35),
        ("delicate", 0.30),
        ("thin", 0.25),
        ("spindly", 0.30),
        ("antenna", 0.25),
        ("wing", 0.20),
        ("spike", 0.20),
        ("needle", 0.25),
    ]

    for t, w in weighted_terms:
        if t in text:
            penalty += w
            notes.append(f"fragility_hint:{t}")
            manual = True

    return min(0.95, penalty), manual, notes


def _estimate_parts_and_hardware(model: MakerWorldModel) -> tuple[int, bool, bool, list[str]]:
    """Estimate part-count and whether extra hardware is needed.

    This is heuristic based on text only. The goal is to penalize large kits and
    operationally annoying builds, not to perfectly count STLs.
    """

    text = " ".join([model.title, model.description, " ".join(model.tags or [])]).lower()
    notes: list[str] = []
    manual = False
    parts_est = 1
    requires_hardware = False

    # Print-in-place is a strong positive signal: usually single print, no assembly.
    # BUT we still scan for hardware requirements (magnets, bearings, etc.) because
    # many print-in-place fidgets rely on extra components.
    if "print in place" in text or "print-in-place" in text:
        notes.append("parts_est:print_in_place")

    if _MULTIPART_RE.search(text):
        parts_est = max(parts_est, 3)
        manual = True
        notes.append("parts_est:multipart")

    if (
        "assembly required" in text
        or "requires assembly" in text
        or "needs assembly" in text
        or "assemble" in text
        or "assembling" in text
    ):
        parts_est = max(parts_est, 3)
        manual = True
        notes.append("parts_est:assembly_terms")

    if "kit card" in text or "kit-card" in text:
        parts_est = max(parts_est, 4)
        manual = True
        notes.append("parts_est:kit_card")

    m = _PARTS_RE.search(text)
    if m:
        try:
            n = int(m.group(1))
            if 1 <= n <= 50:
                parts_est = max(parts_est, n)
                manual = True if n > 2 else manual
                notes.append(f"parts_est:explicit:{n}")
        except Exception:
            pass

    # "Set of" often implies multiple prints (not necessarily assembly, but still
    # slower/less suitable for blind boxes).
    if "set of" in text or "pack of" in text:
        parts_est = max(parts_est, 3)
        manual = True
        notes.append("parts_est:set_or_pack")

    for term in _HARDWARE_TERMS:
        if term in text:
            requires_hardware = True
            manual = True
            notes.append(f"requires_hardware_hint:{term}")
            break

    # Bound to keep scoring stable.
    parts_est = max(1, min(50, int(parts_est)))
    return parts_est, requires_hardware, manual, notes


def estimate_printability(
    model: MakerWorldModel,
    *,
    cls_type: Literal["fidget", "figurine", "mini-toy", "utility", "other"],
    max_dimension_mm_target: int,
) -> PrintabilityResult:
    notes: list[str] = []
    manual_review = False

    text = " ".join([model.title, model.description])
    text_l = text.lower()

    dim = _infer_dimension_mm_from_text(text)
    if dim is None:
        # Tag-based defaults
        tags = [t.lower() for t in (model.tags or [])]
        if any("keycap" in t for t in tags):
            dim = 20
        elif any("keychain" in t or "keyring" in t for t in tags):
            dim = 60
        else:
            dim = 60
        notes.append("dimension_inferred_from_defaults")

    supports_required, supports_uncertain, supports_notes = _supports_signals(model, cls_type)
    if supports_notes:
        notes.extend(supports_notes)
    if supports_uncertain:
        manual_review = True
    supports = supports_required

    parts_est, requires_hardware, parts_manual, parts_notes = _estimate_parts_and_hardware(model)
    if parts_notes:
        notes.extend(parts_notes)
    if parts_manual:
        manual_review = True
    if requires_hardware:
        manual_review = True
    fill_ratio = _FILL_RATIO_BY_CLASS.get(cls_type, 0.035)

    # Compute grams + time
    bbox_cm3 = (float(dim) ** 3) / 1000.0
    grams = bbox_cm3 * _PLA_DENSITY * fill_ratio

    # scaling logic if too big
    scaling_used = False
    scaling_ok = True
    scale_factor = 1.0
    if dim > max_dimension_mm_target:
        scaling_used = True
        # Can we scale down?
        if dim <= int(max_dimension_mm_target * 1.375):  # up to ~110mm when target is 80mm
            scale_factor = max_dimension_mm_target / float(dim)
            dim_scaled = max_dimension_mm_target
            grams = grams * (scale_factor ** 3)
            dim = dim_scaled
            notes.append(f"scaled_down_by_factor:{scale_factor:.2f}")

            # Conservative detail-loss check
            is_detailed = any(t in text_l for t in _DETAIL_TERMS)
            if scale_factor < 0.85 and cls_type in {"figurine", "mini-toy"} and is_detailed:
                scaling_ok = False
                manual_review = True
                notes.append("scaling_risk_detail_loss")
        else:
            notes.append("too_large_to_scale_safely")
            scaling_ok = False
            manual_review = True

    time_minutes = int(round(_TIME_OVERHEAD_MIN + grams * _MIN_PER_GRAM))
    time_minutes = max(1, time_minutes)

    frag_pen, frag_manual, frag_notes = _fragility_penalty(model)
    if frag_notes:
        notes.extend(frag_notes)
    if frag_manual:
        manual_review = True

    # Stricter than v1: thin appendages were still surfacing too often.
    durability_ok = frag_pen < 0.25
    if not durability_ok:
        notes.append("durability_risk:fragile_geometry")

    if supports:
        manual_review = True
        notes.append("supports_required")

    notes.append("estimates_uncertainty:+/-30% (layer=0.2mm,infill=15%,2walls,PLA)")

    est = PrintEstimate(
        max_dimension_mm=int(dim),
        grams_est=float(round(grams, 1)),
        time_minutes_est=int(time_minutes),
        supports_likely=bool(supports),
        parts_est=int(parts_est),
        scaled_down=bool(scaling_used),
        scale_factor=float(round(scale_factor, 4)),
        requires_hardware=bool(requires_hardware),
        fragility_risk=float(round(frag_pen, 4)),
    )

    return PrintabilityResult(
        estimate=est,
        notes=notes,
        manual_review_required=manual_review,
        durability_ok=durability_ok,
        scaling_used=scaling_used,
        scaling_ok=scaling_ok,
    )
