from __future__ import annotations

import httpx

from app.logging_utils import get_logger
from app.schemas import RecommendationItem

log = get_logger(__name__)


def _format_short_message(items: list[RecommendationItem], *, region: str) -> str:
    if not items:
        return f"TrendPrint ({region}): no DO/MAYBE items met hard constraints this run."
    top = items[:5]
    lines = [f"TrendPrint ({region}) — Top {len(top)}:"]
    for it in top:
        lines.append(f"- {it.verdict} {it.scores.total:.1f}/100: {it.model.title} ({it.model.makerworld_url})")
    return "\n".join(lines)


def post_webhook(url: str, content: str) -> None:
    try:
        with httpx.Client(timeout=10.0) as client:
            # Slack/Discord compatible minimal payloads differ; we send both keys.
            payload = {"text": content, "content": content}
            r = client.post(url, json=payload)
            if r.status_code >= 400:
                log.warning("webhook_failed", extra={"status_code": r.status_code, "body": r.text[:200]})
    except Exception as e:
        log.warning("webhook_exception", extra={"error": str(e)})


def notify_webhooks(items: list[RecommendationItem], *, region: str, slack_url: str | None, discord_url: str | None) -> None:
    msg = _format_short_message(items, region=region)
    if slack_url:
        post_webhook(slack_url, msg)
    if discord_url:
        post_webhook(discord_url, msg)
