# TrendPrint Recommendations — UK — 2026-01-12 00:00 UTC

Total shortlisted: **2**

| Rank | Verdict | Score | Model | Type | Time | Grams | Max dim | License | Manual review |
|---:|:---:|---:|---|---|---:|---:|---:|---|:---:|
| 1 | DO | 86.4 | [Print-in-Place Clicky Fidget Slider](https://makerworld.com/en/models/123456-print-in-place-clicky-fidget-slider) | fidget | 50 | 14.2 | 65 | CC BY 4.0 |  |
| 2 | MAYBE | 77.2 | [Mini Desk Buddy — Cute Cat](https://makerworld.com/en/models/234567-mini-desk-buddy-cute-cat) | figurine | 40 | 9.8 | 55 | CC0 |  |

---

## 1. Print-in-Place Clicky Fidget Slider

- MakerWorld: https://makerworld.com/en/models/123456-print-in-place-clicky-fidget-slider
- Creator: ExampleMaker
- Verdict: **DO** (score: **86.4/100**)
- Type: `fidget` (confidence: 0.92)
- Print estimate: 50 min, 14.2 g, max dim 65 mm, supports likely: False
- License: `CC BY 4.0`
- Trend (UK): momentum 82.0/100; evidence: desk fidget, clicky fidget, stress toy
- Tags: fidget, print-in-place, slider, desk

Why this might sell / key checks:
- trend_breakout_signal:82/100
- trend_related_queries:desk fidget; clicky fidget; stress toy
- model_popularity:likes=340,downloads=5200,makes=110
- print_estimate:50min,14.2g
- printability:likely_supportless
- filament_cost_est:~£0.28 (assumes £20/kg PLA)
- license_check:cc_by_allows_commercial (CC BY 4.0)
- estimates_uncertainty:+/-30% (layer=0.2mm,infill=15%,2walls,PLA)

---

## 2. Mini Desk Buddy — Cute Cat

- MakerWorld: https://makerworld.com/en/models/234567-mini-desk-buddy-cute-cat
- Creator: CatPrintsUK
- Verdict: **MAYBE** (score: **77.2/100**)
- Type: `figurine` (confidence: 0.74)
- Print estimate: 40 min, 9.8 g, max dim 55 mm, supports likely: False
- License: `CC0`
- Trend (UK): momentum 64.0/100; evidence: mini animals, desk buddy, tiny figurine
- Tags: cat, cute, figurine, desk buddy

Why this might sell / key checks:
- trend_rising:64/100
- trend_related_queries:mini animals; desk buddy; tiny figurine
- model_popularity:likes=120,downloads=1900,makes=45
- print_estimate:40min,9.8g
- printability:likely_supportless
- filament_cost_est:~£0.20 (assumes £20/kg PLA)
- license_check:cc0_allows_commercial (CC0)
- estimates_uncertainty:+/-30% (layer=0.2mm,infill=15%,2walls,PLA)
