from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from app.logging_utils import get_logger

log = get_logger(__name__)

_WHITESPACE_RE = re.compile(r"\s+")
_PUNCT_RE = re.compile(r"[^a-z0-9\s\-\+\&']+", re.IGNORECASE)

# Hard reject terms for kid-friendly mainstream blind-box products
_HARD_BANNED_TERMS = {
    # Adult / explicit
    "nsfw",
    "nude",
    "porn",
    "porno",
    "sex",
    "sexy",
    "erotic",
    "hentai",
    # Weapons / dangerous items
    "gun",
    "pistol",
    "rifle",
    "shotgun",
    "ammo",
    "ammunition",
    "bullet",
    "knife",
    "dagger",
    "sword",
    "katana",
    "grenade",
    "bomb",
    "explosive",
    "silencer",
    "suppressor",
    # Political (avoid for kids + controversy)
    "election",
    "vote",
    "brexit",
    "labour party",
    "conservative party",
    "tory",
    "ukip",
    "reform uk",
}

# Soft flags: allow but require manual review (seasonal spooky etc.)
_SOFT_FLAG_TERMS = {
    "skull",
    "horror",
    "creepy",
    "zombie",
    "blood",
    "gore",
    "satan",
}

# Trend keywords that are usually *news / event / celebrity-query intent* rather than
# something you can sensibly turn into a small, sellable blind-box print.
# (We still keep the raw trend snapshot in DB; this only affects search.)
_NON_PRODUCTIZABLE_TERMS = {
    "live",
    "stream",
    "watch",
    "tickets",
    "score",
    "scores",
    "result",
    "results",
    "highlights",
    "news",
    "latest",
    "update",
    "episode",
    "season",
    "trailer",
    "release",
    "release date",
    "net worth",
    "age",
    "lyrics",
    "meaning",
    "near me",
    "how to",
}

_PHYSICAL_HINT_TERMS = {
    "toy",
    "fidget",
    "figurine",
    "figure",
    "keychain",
    "keyring",
    "charm",
    "keycap",
    "desk",
    "mini",
}

# Lightweight stopwords used when building a "core" keyword for search.
_STOPWORDS = {
    "the",
    "a",
    "an",
    "and",
    "or",
    "of",
    "for",
    "in",
    "on",
    "at",
    "to",
    "from",
    "with",
    "by",
    "uk",
    "gb",
    "england",
    "britain",
    "british",
    "today",
    "now",
    "latest",
    "new",
}

# Simple synonym expansions for MakerWorld search
_SYNONYMS = {
    "keychain": ["keyring", "key fob"],
    "key ring": ["keyring", "key fob"],
    "pokemon": ["pokémon"],  # unicode variation
    "football": ["soccer"],  # sometimes models use US term
    "fidget": ["fidget toy", "desk fidget"],
    "charm": ["keychain", "keyring"],
}


@dataclass(frozen=True)
class NormalizedKeyword:
    source_keyword: str
    normalized_keyword: str
    expansions: list[str]
    rejected_reason: str | None = None
    manual_review_required: bool = False


def normalize_text(text: str) -> str:
    t = text.lower().strip()
    t = t.replace("’", "'")
    t = t.replace("&", " and ")
    t = _PUNCT_RE.sub(" ", t)
    # Drop simple possessive suffixes to improve matching ("king's" -> "king").
    t = re.sub(r"\b([a-z0-9]+)'s\b", r"\1", t)
    t = _WHITESPACE_RE.sub(" ", t).strip()
    return t


def _strip_phrases(text: str, phrases: set[str]) -> str:
    out = f" {text} "
    for p in phrases:
        if " " in p and p in out:
            out = out.replace(p, " ")
    return _WHITESPACE_RE.sub(" ", out).strip()


def _core_keyword(normalized_keyword: str) -> str:
    """Return a simplified keyword used for search.

    Removes some stopwords and common query clutter so MakerWorld search is less
    likely to match irrelevant news-only strings.
    """

    t = _strip_phrases(normalized_keyword, _NON_PRODUCTIZABLE_TERMS)
    tokens = []
    for tok in t.split():
        if tok.isdigit():
            continue
        if tok in _STOPWORDS:
            continue
        tokens.append(tok)
    return " ".join(tokens).strip()


def _looks_non_productizable(normalized_keyword: str) -> str | None:
    """Return a rejection reason if this keyword is unlikely to map to a product."""

    t = f" {normalized_keyword} "

    # Strong event pattern: "A vs B". This is almost always scores/results/tickets intent.
    if re.search(r"\b(vs|v)\b", t):
        # If the query explicitly contains a physical hint (rare), keep it.
        if not any(h in t for h in _PHYSICAL_HINT_TERMS):
            return "event_query_vs"

    # Obvious non-productizable query intent.
    if any(p in t for p in _NON_PRODUCTIZABLE_TERMS) and not any(h in t for h in _PHYSICAL_HINT_TERMS):
        return "non_productizable_query"

    return None


def _pluralize_simple(word: str) -> str:
    if word.endswith("y") and len(word) > 2 and word[-2] not in "aeiou":
        return word[:-1] + "ies"
    if word.endswith(("s", "x", "z", "ch", "sh")):
        return word + "es"
    return word + "s"


def _singularize_simple(word: str) -> str:
    # Very naive; good enough for keyword expansion
    if word.endswith("ies") and len(word) > 4:
        return word[:-3] + "y"
    if word.endswith("es") and len(word) > 3:
        return word[:-2]
    if word.endswith("s") and len(word) > 3:
        return word[:-1]
    return word


def _contains_phrase(haystack: str, phrase: str) -> bool:
    return phrase in haystack


def is_hard_banned(text: str) -> bool:
    t = normalize_text(text)
    for term in _HARD_BANNED_TERMS:
        if _contains_phrase(t, term):
            return True
    return False


def is_soft_flag(text: str) -> bool:
    t = normalize_text(text)
    for term in _SOFT_FLAG_TERMS:
        if _contains_phrase(t, term):
            return True
    return False


class KeywordNormalizer:
    def __init__(self, max_expansions: int = 12):
        self.max_expansions = max_expansions

    def expand(self, normalized_keyword: str) -> list[str]:
        expansions: list[str] = []
        tokens = normalized_keyword.split()

        # base keyword
        expansions.append(normalized_keyword)

        # Hyphen variants: "spider-man" -> "spider man" / "spiderman"
        if "-" in normalized_keyword:
            expansions.append(normalized_keyword.replace("-", " "))
            expansions.append(normalized_keyword.replace("-", ""))

        # Core keyword (stopwords / query clutter removed)
        core = _core_keyword(normalized_keyword)
        if core and core != normalized_keyword:
            expansions.append(core)

        # singular/plural for single token
        if len(tokens) == 1:
            w = tokens[0]
            expansions.append(_pluralize_simple(w))
            expansions.append(_singularize_simple(w))
        elif len(tokens) >= 2:
            # pluralize the last token (common case: "desk toy" -> "desk toys")
            last = tokens[-1]
            base = tokens[:-1]
            expansions.append(" ".join(base + [_pluralize_simple(last)]))
            expansions.append(" ".join(base + [_singularize_simple(last)]))

        # synonyms (also include replacement variants)
        for k, syns in _SYNONYMS.items():
            if k in normalized_keyword:
                for syn in syns:
                    expansions.append(syn)
                    expansions.append(normalized_keyword.replace(k, syn))
                    if core and k in core:
                        expansions.append(core.replace(k, syn))

        # dedupe, keep order
        seen = set()
        out: list[str] = []
        for e in expansions:
            e2 = normalize_text(e)
            if not e2:
                continue
            if e2 in seen:
                continue
            seen.add(e2)
            out.append(e2)

        return out[: self.max_expansions]

    def normalize_keywords(self, source_keywords: Iterable[str]) -> list[NormalizedKeyword]:
        out: list[NormalizedKeyword] = []
        seen_norm = set()

        for sk in source_keywords:
            norm = normalize_text(sk)
            if not norm:
                continue

            if norm in seen_norm:
                continue

            if is_hard_banned(norm):
                out.append(
                    NormalizedKeyword(
                        source_keyword=sk,
                        normalized_keyword=norm,
                        expansions=[],
                        rejected_reason="hard_banned_keyword",
                        manual_review_required=False,
                    )
                )
                continue

            reject_reason = _looks_non_productizable(norm)
            if reject_reason:
                out.append(
                    NormalizedKeyword(
                        source_keyword=sk,
                        normalized_keyword=norm,
                        expansions=[],
                        rejected_reason=reject_reason,
                        manual_review_required=False,
                    )
                )
                continue

            manual = is_soft_flag(norm)
            expansions = self.expand(norm)

            out.append(
                NormalizedKeyword(
                    source_keyword=sk,
                    normalized_keyword=norm,
                    expansions=expansions,
                    rejected_reason=None,
                    manual_review_required=manual,
                )
            )
            seen_norm.add(norm)

        return out
