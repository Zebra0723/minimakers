from __future__ import annotations

from dataclasses import dataclass

from app.logging_utils import get_logger

log = get_logger(__name__)


@dataclass(frozen=True)
class LicenseDecision:
    allowed: bool
    reason: str
    normalized: str | None = None


def _norm(license_str: str) -> str:
    return " ".join((license_str or "").lower().replace("–", "-").replace("—", "-").split())


def _decision(*, allowed: bool, reason: str, normalized: str | None, raw: str | None = None) -> LicenseDecision:
    # Explicit logging for rejects helps catch licensing regressions.
    if not allowed:
        log.warning(
            "license_rejected",
            extra={"reason": reason, "license_normalized": normalized or "", "license_raw": (raw or "")[:160]},
        )
    return LicenseDecision(allowed=allowed, reason=reason, normalized=normalized)


def check_commercial_license(license_str: str, *, allow_membership: bool = False) -> LicenseDecision:
    '''
    Hard gate: only allow licenses that clearly permit commercial use of printed objects.

    Strategy:
    - If license is missing/unknown → reject.
    - If it contains "NC" / "NonCommercial" / "Personal use" → reject.
    - If it contains "CC BY", "CC0", "CC BY-SA", "CC BY-ND" → allow.
    - If it refers to a "Commercial License Membership" / subscription:
        - reject by default unless allow_membership=True (still recommend manual review).
    '''
    if not license_str or not str(license_str).strip():
        return _decision(allowed=False, reason="missing_license", normalized=None, raw=None)

    raw = str(license_str).strip()
    n = _norm(raw)

    # Common hard rejects
    if "noncommercial" in n or "non-commercial" in n or " nc" in f" {n} " or "cc by-nc" in n or "cc-by-nc" in n:
        return _decision(allowed=False, reason="noncommercial_license", normalized=n, raw=raw)
    if "personal use" in n or "personal-use" in n or "for personal" in n:
        return _decision(allowed=False, reason="personal_use_only", normalized=n, raw=raw)

    # MakerWorld commercial membership style
    if "commercial license membership" in n or ("commercial" in n and "membership" in n):
        if allow_membership:
            # Still recommend manual review; membership licensing can be nuanced.
            return _decision(allowed=True, reason="commercial_membership_config_enabled", normalized=n, raw=raw)
        return _decision(allowed=False, reason="commercial_membership_requires_config", normalized=n, raw=raw)

    # Allow-list Creative Commons
    if "cc0" in n:
        return _decision(allowed=True, reason="cc0_allows_commercial", normalized=n, raw=raw)

    # CC BY, BY-SA, BY-ND allow commercial (NC variants already rejected above)
    if "cc by" in n or "cc-by" in n or "attribution" in n:
        return _decision(allowed=True, reason="cc_by_allows_commercial", normalized=n, raw=raw)

    # If it says "commercial use allowed"
    if "commercial use allowed" in n or ("commercial" in n and "allowed" in n):
        return _decision(allowed=True, reason="explicit_commercial_allowed", normalized=n, raw=raw)

    # Everything else is ambiguous → reject.
    return _decision(allowed=False, reason="ambiguous_or_unknown_license", normalized=n, raw=raw)
